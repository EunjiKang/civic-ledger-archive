# Civic Ledger — GitHub Pages package — v23

This is the complete, already-built website. It replaces the v22 deployment package and uses the two images supplied by the author for Article 4 and technical paper article 2.

## Publish to GitHub Pages

1. Unzip this package. Upload **the contents**, including the hidden `.github` folder, to your repository root. `index.html`, `assets/`, `tools/`, `site.config.json` and `.github/workflows/pages.yml` must sit at the root. Do not upload the ZIP itself or a wrapper folder. Back up an existing repository with a commit or branch first; retain any intentional custom-domain settings.
2. In the repository, choose **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Push to `main` or `master`. The included **Publish Civic Ledger** workflow prepares the public URLs and deploys the site. If the first run happened before Pages was enabled, rerun it from **Actions → Publish Civic Ledger → Run workflow**. For a differently named default branch, update `branches` in the workflow.

On a Mac, `Command + Shift + .` shows hidden files and folders. No passwords, access tokens, npm dependencies or local build tools are required for this workflow. The GitHub-hosted build uses Python's standard library. The source is prepared here; no repository has been changed or deployed by the package creator.

Official GitHub instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## 한국어 업로드 안내

압축을 풀고 **폴더 안의 전체 내용**을 저장소 최상위에 올리세요. `index.html`과 `assets`, `tools`, `site.config.json`, **숨김 폴더 `.github`**를 함께 올려야 합니다. ZIP 파일 자체나 바깥 폴더 한 겹을 올리는 방식은 아닙니다.

**Settings → Pages → Source → GitHub Actions**를 선택한 뒤 `main` 또는 `master`에 커밋하면 **Publish Civic Ledger**가 실행됩니다. 기존 저장소는 먼저 백업하고, 현재 도메인 설정은 유지하세요. 이 패키지는 DNS나 사용자 지정 도메인을 자동으로 변경하지 않습니다.

## Entry points

- `index.html`: English Writing.
- `ko.html`: 한국어 글과 연구.
- `events.html`: Korean Event & Update; use `#events?lang=en` for English.
- `catalogue.html`: Korean reader-only catalogue; use `#catalogue?lang=en` for English.
- `article-4-en.html`, `article-paper2-ko.html`, and the other `article-*.html` files: individual article links with crawler-readable sharing metadata, redirecting to the corresponding reading view.

The deployment tool uses the actual GitHub Pages base URL, including a repository subpath when present. It updates the runtime's public base URL, article canonical URLs and absolute Open Graph image URLs. It does not configure a domain or change DNS.

## v23 image update

- **Article 4 — Beyond the optimal answer: AI that widens what is possible**: `assets/claudio-schwarz-cM-SE4f8d34-unsplash.jpg`.
- **Technical paper article 2 — Fuzzy Ruling Spaces**: `assets/1fuzzy-ruling-concept-sketch.jpg`.
- Both uploaded files are included byte-for-byte. The site uses a responsive landscape crop; the sketch is framed around “Fuzzy Ruling” and “Interpret ↔ Verify”. Neither image has been redrawn, retouched or recoloured.
- The two former “Image forthcoming” thumbnail slots are replaced in both languages. Article 5 and Paper 1 remain forthcoming.
- Korean and English social-preview images have been regenerated for these two articles. The in-page share composer uses the same selected images.
- The photograph is credited as **Claudio Schwarz / Unsplash**, following the supplied filename. See `assets/image-credits-v23.json` for provenance and original-file checksums. The source page was not independently retrieved during this update; this attribution is not a new rights verification. The site-wide CC notice does not relicense the third-party photograph.
- All article text, internal article illustrations, contributor data, layout and other existing interactions remain as in v22.

## Included files

`assets/site-v23.css`, `assets/site-data-v23.js` and `assets/site-v23.js` contain the complete public styles, content and behaviour. `assets/` also contains all local article images, participant-material slide images, and ten static sharing images. `tools/prepare_pages.py` and `.github/workflows/pages.yml` prepare and deploy the public files only.

The separate **Editable Source v23** package includes the organised JSON/CSS/JavaScript and `build.py`, for future editing. It is not necessary to upload it to launch this site. To edit, extract that package separately, change the files in `src/`, run `python3 build.py --web --output public`, and replace the generated public files in this deployment package. Keep the deployment workflow and `tools/` directory. If a title or thumbnail changes later, regenerate the associated static sharing image as well.

## What is and is not live

- This is a static website. Likes, comments and highlights retain their existing browser-local storage; they are not shared between visitors.
- Personal notes are not automatically included in shared post text.
- The meeting form prepares a 30-minute proposal for `koo@darkmatterlabs.org` (technical collaboration) or `eunji@darkmatterlabs.org` (research/pilot/other collaboration). The visitor reviews and sends it in Google Calendar or email. It does not read live availability, confirm a booking, or generate a Google Meet link.
- A public appointment-booking URL can be added later in `site.config.json` under the relevant host's `appointmentBookingUrl`.
- Webfonts remain externally hosted; fallback fonts are used when unavailable. No font files are bundled.
- No DOCX manuscripts, private editorial notes, account credentials, original participant documents with test accounts, or local test servers are included.
- Browser checks used offline Chromium rendering with external fonts unavailable. The GitHub deployment preparation step was tested locally, not executed on a real GitHub repository. Social-network posting, TestFlight participation and Android installation have not been tested in this update.

## Local preview

After extracting all files, run `python3 -m http.server 8000` in this folder and open `http://localhost:8000/`. This previews the relative asset paths under a local server. Public social-preview URLs are populated by the GitHub workflow, not by opening a local HTML file.

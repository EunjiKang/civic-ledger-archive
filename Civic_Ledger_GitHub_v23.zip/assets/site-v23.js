'use strict';
(() => {
 const DATA = window.CIVIC_SITE_DATA || JSON.parse(document.getElementById('site-data').textContent);
 const CODE = window.CIVIC_RUNTIME_DATA || JSON.parse(document.getElementById('runtime-data').textContent);
 const $ = id => document.getElementById(id);
 const esc = x => String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const img = key => DATA.assets[key] || '';
 const hydrate = text => text.replace(/@@ASSET:([^@]+)@@/g,(_,key)=>img(key));
 let lang = document.body.dataset.defaultLang || 'en';
 let filter = 'all', query = '', currentPage = '', activeArticle = null, readerCleanup = null, catalogueReady = false;
 let currentTheme='light';
 try {currentTheme=localStorage.getItem('civic-journal-theme-v8')||'light';}catch(_){}
 const copy = {
 en:{contact:'Contact',writing:'Writing',catalogue:'Functional catalogue',events:'Event & Update',apps:'Tools & apps',skip:'Skip to content',
 kicker:'Writing & research',introTitle:'Writing, research & work in progress.',intro:'Essays on permission, conditions and trust. Two further pieces will explore fuzzy ruling and data.',series:'A growing series',seriesNote:'Three essays, followed by two new lines of inquiry.',all:'All writing',essays:'Essays 01–03',forthcoming:'Forthcoming',search:'Search writing…',feature:'Start here',essay:'Essay',edited:'Annotated edition',draft:'Source draft',read:'Read the essay',readDraft:'Read the draft',authors:'Ahyoung Park · Eunji Kang',cityCaption:'The city, seen through permission',suppliedImage:'Supplied editorial image',next:'Continue the series',seriesCaption:'Permission → Dialogue → Trust',futureLabel:'Next in the series',futureCaption:'Two further essays',fuzzy:'Fuzzy ruling',data:'Data',futureBody:'Forthcoming article. The manuscript is not included in this edition.',fuzzyTopic:'Interpretation and human agency',dataTopic:'Civic data and its governance',noMatch:'No writing matches this search.',noMatchHelp:'Try “permission”, “trust”, “fuzzy” or “data”.',crossKicker:'From the ideas to the functions',crossBody:'Explore the capabilities behind the work.',crossLink:'Open the functional catalogue',indexNote:'Edition note: Blog 1 uses the revised annotated text. Blogs 2 and 3 retain the supplied draft wording, with the Civic Ledger name. Their English consistency review remains open.',back:'← All writing',nextEssay:'Next essay →',sourceStatus:'Source draft · article',sourceNotice:'Source draft. The text below comes from the supplied article compilation; only the project name has been standardised to Civic Ledger. It has not yet had Blog 1’s paragraph-by-paragraph English review. Layout does not indicate factual verification or publication approval.',contents:'In this article',sourceFigure:'Figure from the supplied Korean article · select to inspect',articleEnd:'Back to the writing index',futureEnd:'Next: fuzzy ruling · forthcoming',
 eventsKicker:'Civic Ledger · Gatherings',eventsTitle:'Gatherings &<br>working sessions.',eventsIntro:'A place for shared inquiry, demonstrations and the materials that remain afterwards.',planning:'In planning',planningTitle:'The next Civic Ledger gathering',planningPlace:'Berlin',planningText:'The participant materials propose another gathering in Berlin. The programme and registration are still to be confirmed here.',planningStatus:'PLANNING NOTE, NOT A CONFIRMED LISTING',planningStatusText:'No registration form or calendar booking is connected.',ask:'Ask about the gathering ↗',planningDetails:'Read the planning note',planningDetailText:'The supplied participant sharing version, p. 38, contains an earlier proposed date. The current visit window supplied by the team is 7–11 October 2026; this is not a five-day public event.',archive:'From the archive',archiveTitle:'From static forms to conditional agreements',archiveSummary:'Governance, licensing and investment beyond the pilot. Materials from the Berlin working sessions, developed in collaboration with <a href="https://www.politicsfortomorrow.eu" target="_blank" rel="noopener noreferrer">Politics for Tomorrow</a>.',archiveDates:'3–5 August 2026 · Medulla, Berlin',archiveLabel:'Participant sharing version · source cover',dataSession:'Who should govern civic data, and for whose benefit?',entitySession:'What kind of entity can hold civic infrastructure?',licenseSession:'How do we keep civic infrastructure open without letting it be taken?',sourceFoot:'Event wording and dates are drawn from the supplied participant sharing version (pp. 1, 18, 23, 30 and 38). This is a source-based programme archive, not a live events feed.',
 footerKicker:'Continue into practice',footerTitle:'Tools & apps.',footerIntro:'Explore the work, try a demonstration, or talk to the team about a local application.',web:'Web',webTitle:'Civic Ledger',webDesc:'Continue to the Civic Ledger site and demonstration environment.',openWeb:'Open Civic Ledger ↗',beta:'Korean application · Beta',betaTitle:'WeSharing',betaDesc:'Visit the WeSharing website or follow the mobile beta installation links.',betaWeb:'Website ↗',ios:'iOS · TestFlight ↗',android:'Android · APK link ↗',betaNote:'Beta installation links listed on the WeSharing website. Availability and access requirements may change.',builders:'For builders',buildersTitle:'Functions & integration',buildersDesc:'Inspect the functions and service chains before discussing an implementation.',browse:'Browse functions →',footerContact:'Connect with the team',top:'Back to top ↑',catalogueLanguage:'The supplied catalogue is in English.',slideCaption:'Source: Civic Ledger — Participant sharing version',close:'Close',fit:'Fit',inspect:'Inspect source image',toolSource:'App links in the participant materials, pp. 13–17. No accounts or passwords are supplied here.',
 summaries:{'1':'What changes when permission becomes a way to design conditions together, rather than simply decide what to prevent?','2':'How dialogue becomes conditions, conditions become commitments, and experience becomes a starting point for the next proposal.','3':'Why trust needs a record of conditions, responsibilities and fulfilment—not simply a rating attached to a person.'}},
 ko:{contact:'문의',writing:'글과 연구',catalogue:'기능 카탈로그',events:'모임·업데이트',apps:'도구와 앱',skip:'본문으로 이동',
 kicker:'글과 연구',introTitle:'<span class="ko-title-line">글, 연구,</span><span class="ko-title-line">그리고 진행 중인 생각.</span>',intro:'허가, 조건, 신뢰를 다루는 세 편의 글. 이어서 퍼지 룰링과 데이터에 관한 두 편의 글을 준비합니다.',series:'이어지는 시리즈',seriesNote:'세 편의 아티클과 두 가지 새로운 탐구 주제.',all:'전체 글',essays:'아티클 01–03',forthcoming:'공개 예정',search:'글 검색…',feature:'시리즈의 시작',essay:'아티클',edited:'주석 포함',draft:'원문 초안',read:'글 읽기',readDraft:'초안 읽기',authors:'박아영 · 강은지',cityCaption:'허가의 관점에서 바라본 도시',suppliedImage:'제공된 에디토리얼 이미지',next:'시리즈 이어 읽기',seriesCaption:'허가 → 대화 → 신뢰',futureLabel:'다음 탐구 주제',futureCaption:'두 편의 후속 아티클',fuzzy:'퍼지 룰링',data:'데이터',futureBody:'공개 예정인 글입니다. 이번 페이지에는 원고가 포함되지 않았습니다.',fuzzyTopic:'해석과 인간의 행위 주체성',dataTopic:'시민 데이터와 거버넌스',noMatch:'검색어와 일치하는 글이 없습니다.',noMatchHelp:'“허가”, “신뢰”, “fuzzy”, “데이터”로 검색해 보세요.',crossKicker:'개념에서 기능으로',crossBody:'이 논의를 뒷받침하는 기능을 살펴보세요.',crossLink:'기능 카탈로그 보기',indexNote:'버전 안내: 첫 번째 글은 수정된 번역과 주석을 사용합니다. 두 번째와 세 번째 글은 프로젝트명을 Civic Ledger로 통일한 제공 원고이며, 영문 번역의 일관성 검토는 진행 전입니다.',back:'← 전체 글',nextEssay:'다음 글 →',sourceStatus:'제공 원고 · 아티클',sourceNotice:'제공 원고입니다. 프로젝트명을 Civic Ledger로 통일한 것 외에는 제공된 아티클 문서의 내용을 유지했습니다. 두 번째와 세 번째 글의 영문은 첫 번째 글과 같은 문단별 번역 검토를 아직 거치지 않았습니다. 페이지 디자인이 사실 확인이나 발행 승인을 의미하지는 않습니다.',contents:'이 글의 구성',sourceFigure:'제공된 한국어 원고의 이미지 · 선택하여 확대',articleEnd:'전체 글로 돌아가기',futureEnd:'다음 주제: fuzzy ruling · 공개 예정',
 eventsKicker:'Civic Ledger · 모임',eventsTitle:'모임과<br>작업 세션.',eventsIntro:'함께 탐구하고 시연하며, 그 과정에서 남은 자료를 공유합니다.',planning:'기획 중',planningTitle:'다음 Civic Ledger 모임',planningPlace:'베를린',planningText:'참가자 공유 자료에는 베를린에서의 후속 모임이 제안되어 있습니다. 프로그램과 참가 신청은 아직 이 페이지에서 확정되지 않았습니다.',planningStatus:'기획 기록 · 확정된 행사 안내가 아닙니다',planningStatusText:'참가 신청 양식이나 캘린더 등록은 연결되지 않았습니다.',ask:'모임에 관해 문의하기 ↗',planningDetails:'기획 기록 보기',planningDetailText:'제공된 참가자 공유 자료 38쪽에는 이전 기획 일정이 남아 있습니다. 팀이 새로 알려준 방문 기간은 2026년 10월 7–11일이며, 공개 행사의 확정 일정은 아닙니다.',archive:'자료 아카이브',archiveTitle:'정적인 서식에서 조건부 합의로',archiveSummary:'파일럿 이후의 거버넌스, 라이선싱, 투자. <a href="https://www.politicsfortomorrow.eu" target="_blank" rel="noopener noreferrer">Politics for Tomorrow</a>와 함께 준비한 베를린 작업 세션의 참가자 공유 자료입니다.',archiveDates:'2026년 8월 3–5일 · Medulla, 베를린',archiveLabel:'참가자 공유 자료 · 원본 표지',dataSession:'시민 데이터는 누가, 누구의 이익을 위해 관리해야 하는가?',entitySession:'어떤 조직이 시민 인프라를 지속적으로 운영할 수 있는가?',licenseSession:'시민 인프라를 열어두면서 어떻게 그 가치를 지킬 수 있는가?',sourceFoot:'행사 내용과 날짜는 제공된 참가자 공유 자료(1, 18, 23, 30, 38쪽)를 기준으로 표시했습니다. 실시간 행사 일정이 아닌, 제공 자료에 기반한 아카이브입니다.',
 footerKicker:'실제 사용으로 이어가기',footerTitle:'도구와 앱.',footerIntro:'작업을 살펴보고 시연에 참여하거나, 지역에서의 적용에 관해 팀과 이야기해 보세요.',web:'웹',webTitle:'Civic Ledger',webDesc:'Civic Ledger 웹사이트와 시연 환경으로 이동합니다.',openWeb:'Civic Ledger 열기 ↗',beta:'한국 적용 서비스 · 베타',betaTitle:'위쉐어링',betaDesc:'위쉐어링 웹사이트를 방문하거나 모바일 베타 설치 링크를 확인하세요.',betaWeb:'웹사이트 ↗',ios:'iOS · TestFlight ↗',android:'Android · APK 링크 ↗',betaNote:'위쉐어링 웹사이트에 게시된 베타 설치 링크입니다. 참여 가능 여부와 접근 조건은 달라질 수 있습니다.',builders:'개발과 적용',buildersTitle:'기능과 연동',buildersDesc:'구현을 논의하기 전에 기능과 서비스 흐름을 살펴보세요.',browse:'기능 살펴보기 →',footerContact:'팀과 연결하기',top:'맨 위로 ↑',catalogueLanguage:'제공된 기능 카탈로그는 영어로 구성되어 있습니다.',slideCaption:'출처: Civic Ledger — Participant sharing version',close:'닫기',fit:'맞춤',inspect:'원본 이미지 확대',toolSource:'앱 링크 출처: 참가자 공유 자료 13–17쪽. 계정이나 비밀번호는 제공하지 않습니다.',
 summaries:{'1':'허가가 무엇을 막을지 판정하는 장치를 넘어, 어떤 조건에서 가능한지를 함께 설계하는 과정이 된다면 무엇이 달라질까요?','2':'대화가 조건이 되고, 조건이 약속이 되며, 그 경험이 다음 제안의 출발점이 되는 과정을 살펴봅니다.','3':'개인에게 붙는 평점이 아니라, 조건과 책임, 이행의 기록이 신뢰의 근거가 되는 구조를 살펴봅니다.'}}
 };
/* Only loaded into the Korean view. Reader controls change display, never copy. */
function ensureKoreanFonts() {
 if(lang!=='ko')return;
 const urls=[
 ['ko-sans-font','https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css'],
 ['ko-serif-font','https://hangeul.pstatic.net/hangeul_static/css/maru-buri.css']
 ];
 urls.forEach(([id,href])=>{if(document.getElementById(id))return;const l=document.createElement('link');l.id=id;l.rel='stylesheet';l.href=href;l.crossOrigin='anonymous';document.head.appendChild(l)});
}
let koReadingSize=null;
try {const n=Number(localStorage.getItem('civic-ko-reading-size'));if(n>=16&&n<=22)koReadingSize=n}catch(_){}
function mountKoreanReadingTools() {
 if(lang!=='ko')return;
 const root=$('article-content');
 const defaultSize=innerWidth<=720?17:18;
 if(koReadingSize)root.style.setProperty('--reading-size',koReadingSize+'px');
 else root.style.removeProperty('--reading-size');
 const host=root.querySelector('.tools')||root.querySelector('.source-toolbar');
 if(!host)return;
 const tools=document.createElement('div');tools.className='ko-reading-settings';tools.setAttribute('role','group');tools.setAttribute('aria-label','본문 글자 크기');
 tools.innerHTML=`<span class="settings-name">글자 크기</span><button type="button" data-ko-size="-1" aria-label="본문 글자 작게">가−</button><span class="ko-size-label" aria-live="polite">${koReadingSize||defaultSize}</span><button type="button" data-ko-size="1" aria-label="본문 글자 크게">가+</button>`;
 host.prepend(tools);
 tools.addEventListener('click',e=>{
  const b=e.target.closest('[data-ko-size]');if(!b)return;
  koReadingSize=Math.max(16,Math.min(22,(koReadingSize||defaultSize)+Number(b.dataset.koSize)));
  root.style.setProperty('--reading-size',koReadingSize+'px');
  tools.querySelector('.ko-size-label').textContent=koReadingSize;
  tools.querySelector('[data-ko-size="-1"]').disabled=koReadingSize===16;
  tools.querySelector('[data-ko-size="1"]').disabled=koReadingSize===22;
  try{localStorage.setItem('civic-ko-reading-size',koReadingSize)}catch(_){}
 });
}

 const t=()=>copy[lang];
 const routeLink=(route)=>'#'+route+'?lang='+lang;
 const meta=id=>{const a=DATA.articles[id+'-'+lang];return {id:String(id),title:a.title,topic:a.topic,collection:a.collection,draft:false};};
 for(const locale of ['en','ko']){
  Object.assign(copy[locale],locale==='ko'?{
   intro:'허가, 대화, 신뢰, AI와 집단적 주체성을 다룬 네 편의 글과, 퍼지 룰링 공간을 소개하는 기술 백서 아티클.',
   series:'Civic Ledger 시리즈',seriesNote:'공개된 아티클 4편과 기술 백서 아티클 1편. 아티클 5와 기술 백서 1은 공개 예정입니다.',essays:'Civic Ledger 시리즈',technical:'기술 백서 아티클',
   read:'글 읽기',readDraft:'글 읽기',draft:'',edited:'',seriesCaption:'허가 → 대화 → 신뢰 → AI',
   futureEnd:'다음 글 · 라이선스와 오픈 라이선스',indexNote:'',sourceNotice:'',sourceFigure:'원고에 포함된 그림 · 선택하여 확대'
  }:{
   intro:'Four essays on permission, dialogue, trust, and AI and collective agency, alongside a separate article on Fuzzy Ruling Spaces.',
   series:'Civic Ledger series',seriesNote:'Four essays and one technical-paper article to read. Article 5 and Paper 1 are forthcoming.',essays:'Civic Ledger series',technical:'Technical paper articles',
   read:'Read the essay',readDraft:'Read the essay',draft:'',edited:'',seriesCaption:'Permission → Dialogue → Trust → AI',
   futureEnd:'Next · Licences and open licences',indexNote:'',sourceNotice:'',sourceFigure:'Figure from the article · select to inspect'
  });
  copy[locale].summaries=Object.fromEntries(DATA.readingOrder.map(id=>[id,DATA.articles[id+'-'+locale].description]));
 }
 function setLabels(){
  document.documentElement.lang=lang==='ko'?'ko':'en-GB';
  ensureKoreanFonts();
  document.querySelectorAll('[data-i18n]').forEach(el=>el.textContent=t()[el.dataset.i18n]);
  document.querySelectorAll('[data-lang]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.lang===lang)));
  document.querySelectorAll('[data-main-route]').forEach(el=>el.href=routeLink(el.dataset.mainRoute));
 }
 function finalCard(x){
  const a=DATA.articles[x.id+'-'+lang],slot=DATA.thumbnailSlots?.[x.id],thumb=slot?.src||DATA.thumbnails[x.id];
  const pending=slot?.status==='pending'&&!slot?.src;
  const forthcoming=a.status==='forthcoming',tag=forthcoming?'article':'a';
  const label=forthcoming?(lang==='ko'?'원고 준비 중':'Work in progress'):(lang==='ko'?'이미지 준비 중':'Image forthcoming');
  const hint=forthcoming?(lang==='ko'?'공개 예정':'Forthcoming'):(lang==='ko'?'본문을 읽을 수 있습니다':'Article available to read');
  const media=!pending&&thumb?`<div class="thumbnail article-card-media"><img src="${img(thumb)}" alt="${esc(slot?.alt?.[lang]||a.topic)}" width="${slot?.sourceWidth||2000}" height="${slot?.sourceHeight||1169}" loading="lazy" decoding="async">${slot?.credit?`<span class="thumbnail-credit">${esc(slot.credit)}</span>`:''}</div>`:`<div class="thumbnail article-card-media is-placeholder ${forthcoming?'placeholder-manuscript':'placeholder-image'}" role="img" aria-label="${esc(label+' · '+hint)}"><span class="thumbnail-placeholder-copy"><span class="thumbnail-placeholder-label">${esc(label)}</span><span class="thumbnail-placeholder-hint">${esc(hint)}</span></span></div>`;
  const badge=a.collection==='technical'?a.collectionLabel:(lang==='ko'?'아티클 ':'Essay ')+a.seriesNumber;
  return `<${tag} class="essay-card ${forthcoming?'is-forthcoming':'essay-link'} ${a.collection==='technical'?'technical-card':''}" data-card-id="${esc(x.id)}" ${forthcoming?'aria-label="'+esc(badge+' · '+(lang==='ko'?'공개 예정':'Forthcoming'))+'"':'href="'+routeLink('article/'+x.id)+'"'}><div class="essay-meta"><span>${esc(badge)}</span>${forthcoming?`<span class="forthcoming-status">${lang==='ko'?'공개 예정':'Forthcoming'}</span>`:''}</div>${media}<div class="article-card-copy"><h2>${esc(x.title)}</h2><p>${esc(a.description)}</p><div class="essay-foot">${forthcoming?`<span class="quiet">${lang==='ko'?'원고 준비 중':'In preparation'}</span><span class="quiet">${lang==='ko'?'공개 예정':'Forthcoming'}</span>`:`<span class="quiet">${esc(t().authors)}</span><span class="read-link">${esc(t().read)} <span class="read-arrow" aria-hidden="true">↗</span></span>`}</div></div></${tag}>`;
 }
 function technicalFeature(x){
  const card=finalCard(x),start=card.indexOf('<div class="essay-meta">'),end=card.indexOf('</div>',start)+6;
  const badge=card.slice(start,end);
  return (card.slice(0,start)+card.slice(end)).replace('class="essay-card ','class="essay-feature technical-feature ').replace('class="article-card-copy">','class="feature-copy">'+badge);
 }
 function renderWriting(){
  const entries=DATA.readingOrder.map(meta).filter(x=>(filter==='all'||filter==='essays'&&x.collection==='series'||filter==='technical'&&x.collection==='technical')&&(!query||[x.title,x.topic,t().summaries[x.id],x.id].join(' ').toLowerCase().includes(query.toLowerCase())));
  const first=entries.find(x=>x.id==='1'),others=entries.filter(x=>x.collection==='series'&&x.id!=='1'),papers=entries.filter(x=>x.collection==='technical');
  let html='';
  if(first)html+=`<a class="essay-feature essay-link" href="${routeLink('article/1')}" aria-label="${esc(t().read+': '+first.title)}"><div class="feature-image"><img src="${img(DATA.thumbnails['1'])}" alt="${esc(t().cityCaption)}" width="2000" height="1165"></div><div class="feature-copy"><div class="essay-meta"><span>${lang==='ko'?'아티클 1 · 시리즈의 시작':'Essay 1 · Start here'}</span></div><h2>${esc(first.title)}</h2><p>${esc(t().summaries['1'])}</p><div class="essay-foot"><span>${esc(t().authors)}</span><span class="read-link">${esc(t().read)} <span class="read-arrow" aria-hidden="true">↗</span></span></div></div></a>`;
  if(others.length)html+=`<div class="essay-grid">${others.map(finalCard).join('')}</div>`;
  if(papers.length){if(filter==='technical'){html+=papers.map(technicalFeature).join('');}else html+=`<div class="essay-grid technical-grid">${papers.map(finalCard).join('')}</div>`;}
  if(!entries.length)html=`<div class="index-empty"><h2>${esc(t().noMatch)}</h2><p>${esc(t().noMatchHelp)}</p></div>`;
  $('writing-items').innerHTML=html;$('writing-results').textContent=entries.length+' / '+DATA.readingOrder.length;
 }
 const searchIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/></svg>';
 function searchField(id,value,placeholder,extraClass){
  return `<div class="civic-search ${extraClass}" role="search"><label class="sr-only" for="${id}">${esc(placeholder)}</label>${searchIcon}<input id="${id}" type="search" autocomplete="off" placeholder="${esc(placeholder)}" value="${esc(value)}"><button type="button" class="search-clear" data-clear-search="${id}" aria-label="${lang==='ko'?'검색어 지우기':'Clear search'}" ${value?'':'hidden'}>×</button></div>`;
 }
 function syncSearchClear(input){const b=input.closest('.civic-search')?.querySelector('[data-clear-search]');if(b)b.hidden=!input.value;}
 function writingScaffold(){
  $('writing-panel').innerHTML=`<div class="shell"><header class="index-intro"><div><div class="section-kicker">${esc(t().kicker)}</div><h1>${t().introTitle}</h1><p class="intro-copy">${esc(t().intro)}</p></div></header><div class="index-tools"><div class="writing-filters" role="group" aria-label="${esc(t().writing)}">${['all','essays','technical'].map(f=>`<button data-writing-filter="${f}" aria-pressed="${filter===f}">${esc(t()[f])}</button>`).join('')}</div>${searchField('writing-search',query,t().search,'writing-search')}</div><div id="writing-results" class="sr-only" aria-live="polite"></div><div id="writing-items"></div>${earlierWriting()}</div>`;
  renderWriting();$('writing-search').addEventListener('input',e=>{query=e.target.value;syncSearchClear(e.target);renderWriting()});
 }
 function makeDoc(root,{article=false}={}){
  return new Proxy(document,{get(target,key){
   if(key==='documentElement')return article?document.documentElement:root;
   if(key==='body')return article?{classList:root.classList,style:document.body.style}:root;
   if(key==='getElementById')return id=>root.querySelector('#'+CSS.escape(id));
   if(key==='querySelector'||key==='querySelectorAll')return root[key].bind(root);
   if(key==='addEventListener'||key==='removeEventListener')return root[key].bind(root);
   const v=Reflect.get(target,key,target);return typeof v==='function'?v.bind(target):v;
  }});
 }
 function initCatalogue(){
  if(catalogueReady)return;
  const root=$('catalogue-root');
  new Function('document','LANGPACK',CODE.catalogue)(makeDoc(root),DATA.catalogueKo);
   window.CivicCatalogue.setLocale(lang);
  catalogueReady=true;
  window.CivicCatalogue.applyTheme(currentTheme);
  root.addEventListener('click',e=>{
   const a=e.target.closest('a[href^="#"]');if(!a)return;
   const target=root.querySelector(a.getAttribute('href'));
   if(target){e.preventDefault();target.scrollIntoView({block:'start',behavior:'smooth'})}
  });
  root.querySelector('#theme-toggle')?.addEventListener('click',()=>setTheme(root.dataset.theme));
 }
 function linkedAuthors(){const names=lang==='ko'?['박아영','강은지']:['Ahyoung Park','Eunji Kang'];const urls=['https://www.linkedin.com/in/ahyoung-park-asum/','https://www.linkedin.com/in/eunjikangsin/'];return names.map((name,i)=>`<a class="team-name-link" href="${urls[i]}" target="_blank" rel="noopener noreferrer">${name}</a>`).join(' · ');}
 function mountBlogOne(key){
  const root=$('article-content');root.className='reading-one js';root.lang=lang;
  root.innerHTML=hydrate(DATA.articles[key].html);
  const byline=root.querySelector(".hero-meta");if(byline)byline.innerHTML=linkedAuthors();
  const credits=root.querySelector('.final-credits');if(credits)credits.innerHTML=finalBlocks(DATA.articles[key].credits,DATA.articles[key].id,{credits:true});
  addReferenceLayout(root,DATA.articles[key]);
  root.querySelectorAll('.publication-check').forEach(el=>el.remove());
  root.querySelector('.mast-inner')?.insertAdjacentHTML('afterbegin',`<a class="back-writing" href="${routeLink('writing')}">${esc(t().back)}</a>`);
  const controller=new AbortController(),observers=[];
  const listen=(event,cb,opts={})=>window.addEventListener(event,cb,{...(typeof opts==='boolean'?{capture:opts}:opts),signal:controller.signal});
  const IO=class extends IntersectionObserver{constructor(cb,opts){super(cb,opts);observers.push(this)}};
  root.addEventListener('click',e=>{
   const a=e.target.closest('a[href^="#"]');if(!a||a.classList.contains('back-writing'))return;
   const id=a.getAttribute('href').slice(1);const target=root.querySelector('#'+CSS.escape(id));
   if(target){e.preventDefault();for(let n=target;n&&n!==root;n=n.parentElement)if(n.tagName==='DETAILS')n.open=true;requestAnimationFrame(()=>target.scrollIntoView({block:'start',behavior:'smooth'}));}
  });
  new Function('document','addEventListener','IntersectionObserver',CODE.article)(makeDoc(root,{article:true}),listen,IO);
  readerCleanup=()=>{controller.abort();observers.forEach(o=>o.disconnect());root.querySelectorAll('dialog[open]').forEach(d=>d.close());document.body.style.overflow='';};
 }
 function referenceRail(a){
  const refs=a.references||[];if(!refs.length)return '';
  const used=refs.filter(r=>r.number).sort((a,b)=>a.number-b.number),other=refs.filter(r=>!r.number);
  const item=r=>`<li class="reference-entry ${r.number?'is-cited':'is-listed'}" id="ref-${a.id}-${lang}-${r.id}" data-reference-id="ref-${a.id}-${lang}-${r.id}" tabindex="-1">${r.number?`<span class="reference-number">${r.number}</span>`:''}<div><p>${r.html||esc(r.text)}</p>${r.occurrences?.length?`<div class="reference-returns">${r.occurrences.map((x,i)=>`<button type="button" data-ref-return="${x.marker}">${lang==='ko'?'본문으로':'Back to text'}${r.occurrences.length>1?' '+(i+1):''} ↩</button>`).join('')}</div>`:''}</div></li>`;
  return `<aside class="reference-rail" aria-label="${lang==='ko'?'출처와 문헌':'Sources and reading'}"><div class="reference-rail-inner"><h2 class="reference-rail-title">${lang==='ko'?'출처와 문헌':'Sources & reading'}</h2>${used.length?`<ol class="reference-list">${used.map(item).join('')}</ol>`:''}${other.length?`<section class="listed-sources"><h3>${lang==='ko'?'원고에 수록된 문헌':'Also listed in the manuscript'}</h3><ul class="reference-list">${other.map(item).join('')}</ul></section>`:''}</div></aside>`;
 }
 function addReferenceLayout(root,a){
  const main=root.querySelector('.page>main');if(!main)return;
  const wrap=document.createElement('div');wrap.className='reading-reference-layout'+(a.references?.length?'':' without-references');
  main.before(wrap);wrap.append(main);main.classList.add('reading-flow');wrap.insertAdjacentHTML('beforeend',referenceRail(a));
 }
 function finalBlocks(blocks,id,{credits=false}={}){
  if(credits){let section='';blocks=blocks.filter(b=>{if(b.type==='heading')section=b.key;return ['authors','team','project-note','references'].includes(section);});}
  let list=null, out='';
  for(const b of blocks){
   if(credits&&b.type==='heading'&&(b.key==='references'||['References','참고문헌'].includes(b.text?.trim())))break;
   const closeList=()=>{if(list){out+='</'+list+'>';list=null;}};
   const attrs=`data-source-paragraph="${b.source_paragraph}"`;
   if(b.type==='list-item'){if(list!==b.list){closeList();list=b.list;out+='<'+list+' class="source-list">';}out+=`<li ${attrs}>${b.display_html||b.html||esc(b.text)}</li>`;continue;}
   closeList();
   if(b.type==='heading'){const level=credits?3:b.level;out+=`<h${level} class="${String(id)==='4'&&b.key==='section-2'?'heading-without-rule':''}" id="${credits?'credit-':''}${esc(b.key)}" data-read-key="${credits?'credit-':''}${esc(b.key)}" data-heading-level="${level}" ${attrs}>${b.display_html||b.html||esc(b.text)}</h${level}>`;}
   else if(b.type==='image')out+=`<figure class="final-figure inline-figure ${b.height>b.width?'portrait-figure':''}" data-source-paragraph="${b.source_paragraph}"><button type="button" aria-label="${esc((lang==='ko'?'전체 이미지 크게 보기: ':'Enlarge the whole image: ')+(b.alt||b.caption))}" data-media="${esc(b.src)}" data-media-title="${esc(b.caption)}" data-media-source="${esc(b.display_caption||b.caption)}"><img src="${img(b.src)}" alt="${esc(b.alt||b.caption)}" width="${b.width}" height="${b.height}" loading="lazy"></button><figcaption ${b.caption_paragraph!==undefined?'data-source-paragraph="'+b.caption_paragraph+'"':''}>${esc(b.display_caption||b.caption)}</figcaption></figure>`;
   else if(b.type==='placeholder')out+=`<aside class="manuscript-image-placeholder" data-source-paragraph="${b.source_paragraph}"><p>${b.display_html||b.html||esc(b.text)}</p></aside>`;
   else if(b.type==='series-note')out+=`<p class="final-series-note" ${attrs}>${b.display_html||b.html||esc(b.text)}</p>`;
   else if(b.type==='quote')out+=`<blockquote class="source-quotation"><p ${attrs}>${b.display_html||b.html||esc(b.text)}</p></blockquote>`;
   else out+=`<p ${attrs}>${b.display_html||b.html||esc(b.text)}</p>`;
  }
  if(list)out+='</'+list+'>';return out;
 }
 function mountSource(id){
  const a=DATA.articles[id+'-'+lang],root=$('article-content');root.className='source-article final-article shell';root.lang=lang;
  root.innerHTML=`<nav class="source-toolbar"><a href="${routeLink('writing')}">${esc(t().back)}</a></nav><header class="source-title"><div class="section-kicker">${esc(a.collectionLabel)}</div><h1>${esc(a.title)}</h1><div class="source-byline">${linkedAuthors()}</div></header><div class="source-layout reading-reference-layout ${a.references?.length?'':'without-references'}"><div class="source-prose reading-flow">${finalBlocks(a.blocks,id)}<div class="final-credits">${finalBlocks(a.credits,id,{credits:true})}</div></div>${referenceRail(a)}</div>`;
 }
 function renderArticle(id){
  if(readerCleanup){readerCleanup();readerCleanup=null}
  const key=id+'-'+lang;if(!DATA.articles[key])return;
  activeArticle=id;document.body.dataset.article=id;
  if(DATA.articles[key].status==='forthcoming'){
   const a=DATA.articles[key],root=$('article-content');root.className='source-article final-article shell';root.lang=lang;
   root.innerHTML=`<header class="source-title forthcoming-title"><div class="section-kicker">${esc(a.collectionLabel)} · ${lang==='ko'?'공개 예정':'Forthcoming'}</div><h1>${esc(a.title)}</h1><p>${esc(a.description)}</p><p class="holding-note">${lang==='ko'?'원고를 준비하고 있습니다.':'The manuscript is in preparation.'}</p><a class="quiet-link" href="${routeLink('writing')}">${esc(t().back)}</a></header>`;
  }else if(id==='1')mountBlogOne(key);else mountSource(id);
  $('article-content').style.removeProperty('--reading-size');$('article-tail').innerHTML='';
 }
 let updateFilter='all',updateQuery='';
 const archiveWords=()=>lang==='ko'?{title:'프로젝트 아카이브',intro:'프로젝트와 행사, 인터뷰·보도를 모았습니다.',all:'전체',article:'글·개발 기록',interview:'인터뷰·보도',project:'프로젝트·행사',material:'자료',search:'소식 검색…',open:'원문',empty:'검색 결과가 없습니다.',pastTitle:'앞선 글과 개발 기록',pastLink:'프로젝트 아카이브 전체 보기',source:'기존 사이트의 업데이트 목록'}:{title:'Project archive',intro:'Projects, events, interviews and coverage.',all:'All',article:'Writing',interview:'Interviews & coverage',project:'Projects & events',material:'Materials',search:'Search updates…',open:'Open',empty:'No matching records.',pastTitle:'Earlier writing & development notes',pastLink:'Explore the project archive',source:'Updates on the original site'};
 function archiveDate(x){
  const raw=(x.date||'').trim(),m=raw.match(/^(\d{4})(?:[.\-](\d{1,2}))?(?:[.\-](\d{1,2}))?$/);
  if(!m)return {key:null,iso:'',label:lang==='ko'?'날짜 미확인':'Date unconfirmed'};
  const year=Number(m[1]),month=m[2]?Number(m[2]):0,day=m[3]?Number(m[3]):0;
  return {key:year*10000+month*100+day,iso:[m[1],m[2]?.padStart(2,'0'),m[3]?.padStart(2,'0')].filter(Boolean).join('-'),label:raw};
 }
 function archiveOrder(a,b){const x=archiveDate(a).key,y=archiveDate(b).key;return x===null?(y===null?0:1):y===null?-1:y-x;}
 function berlinMaterials(){const ko=lang==='ko';return `<details class="session-materials is-nested" data-berlin-materials><summary><span>${ko?'베를린 작업 세션 · 참가자 자료':'Berlin working sessions · participant materials'}</span><span>03—05 AUG 2026 <b aria-hidden="true">＋</b></span></summary><p>${esc(t().archiveSummary)}</p>${[['1','01',t().archiveTitle],['18','02',t().dataSession],['23','03',t().entitySession],['30','04',t().licenseSession]].map(([page,num,title])=>`<button type="button" class="session-row" data-media="${esc(DATA.slides[page])}" data-media-title="${esc(title)}" data-media-source="Civic Ledger · Participant sharing version · p. ${page}"><span class="num">${num}</span><span class="label">${esc(title)}</span><span aria-hidden="true">↗</span></button>`).join('')}</details>`;}
 function archiveRow(x,{compact=false}={}){
  const w=archiveWords(),date=archiveDate(x);
  const stamp=date.iso?`<time datetime="${date.iso}">${esc(date.label)}</time>`:`<span class="date-unconfirmed">${esc(date.label)}</span>`;
  return `<li class="archive-list-item" data-archive-id="${esc(x.id)}" data-date="${esc(date.iso)}"><a class="archive-link" href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">${compact?'':`<span class="archive-meta">${stamp}<span class="archive-type">${esc(w[x.type])}</span></span>`}<span class="archive-link-title" lang="en">${esc(x.title.en)}</span><span class="archive-link-action">${esc(w.open)} <span aria-hidden="true">↗</span></span></a></li>`;
 }
 function earlierWriting(){
  const w=archiveWords();return `<section class="earlier-writing" aria-labelledby="earlier-writing-title"><header class="archive-heading"><h2 id="earlier-writing-title">${esc(w.pastTitle)}</h2></header><ul class="archive-link-list compact">${(DATA.updates||[]).filter(x=>x.writing).sort(archiveOrder).map(x=>archiveRow(x,{compact:true})).join('')}</ul></section>`;
 }
 function renderUpdateList(){
  const w=archiveWords(),eligible=(DATA.updates||[]).filter(x=>['interview','project'].includes(x.type)).sort(archiveOrder);
  if(!['all','interview','project'].includes(updateFilter))updateFilter='all';
  const list=eligible.filter(x=>(updateFilter==='all'||x.type===updateFilter)&&(!updateQuery||[x.title.en,x.title.ko,x.publisher,w[x.type]].join(' ').toLowerCase().includes(updateQuery.toLowerCase())));
  $('update-list').innerHTML=list.length?list.map(x=>archiveRow(x)).join(''):`<li class="archive-empty">${esc(w.empty)}</li>`;
  $('update-count').textContent=list.length+' / '+eligible.length;
 }
 function downloadBerlinVisit(){
  const ko=lang==='ko';
  const description=ko?'Civic Ledger 베를린 방문 예정 기간. 공개 행사 일정이 아닙니다. 장소와 프로그램은 미정입니다. 팀 제공 일정 (2026-09-25).':'Planned Civic Ledger visit window in Berlin, supplied by the team on 25 September 2026. Not a confirmed public event. Venue and programme to be confirmed.';
  const fold=s=>{let rows=[],line='',bytes=0;for(const ch of s){const n=new TextEncoder().encode(ch).length;if(bytes+n>73){rows.push(line);line=' ';bytes=1}line+=ch;bytes+=n}rows.push(line);return rows.join('\r\n');};
  const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Civic Ledger//Journal visit reminder//EN','CALSCALE:GREGORIAN','METHOD:PUBLISH','BEGIN:VEVENT','UID:berlin-visit-20261007@civicledger.city','DTSTAMP:20260925T000000Z','DTSTART;VALUE=DATE:20261007','DTEND;VALUE=DATE:20261012','SUMMARY:'+(ko?'Civic Ledger · 베를린 방문 예정':'Civic Ledger · planned Berlin visit'),'LOCATION:Berlin','DESCRIPTION:'+description.replace(/,/g,'\\,'),'STATUS:TENTATIVE','TRANSP:TRANSPARENT','END:VEVENT','END:VCALENDAR'];
  const blob=new Blob([lines.map(fold).join('\r\n')+'\r\n'],{type:'text/calendar;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Civic-Ledger-Berlin-visit-7-11-Oct-2026.ics';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }

 function renderEvents(){
  const ko=lang==='ko',w=archiveWords(),ext='target="_blank" rel="noopener noreferrer"';
  const visit={title:ko?'다시, 베를린으로.':'Back to Berlin.',intro:ko?'다가올 만남과, 지금까지의 작업을 함께 살펴봅니다.':'Upcoming conversations and a record of the work so far.',status:ko?'방문 예정':'Upcoming visit',date:ko?'2026년 10월 7–11일':'7–11 October 2026',note:ko?'방문 기간 중 3일 동안 다음 세 가지를 진행합니다.':'Three days of work during the visit:',contact:ko?'만남 문의하기':'Request a meeting',calendar:ko?'방문 기간 저장':'Save visit window'};
  $('events-panel').innerHTML=`<div class="shell events-v8"><header class="events-intro"><div><div class="section-kicker">${ko?'모임과 업데이트':'Event &amp; Update'}</div><h1>${ko?'모임과 업데이트.':'Events &amp; updates.'}</h1></div><p>${esc(visit.intro)}</p></header>
  <section class="next-visit" aria-labelledby="berlin-visit-title"><div class="visit-stamp"><span class="micro">${ko?'다음 방문':'Next visit'}</span><strong>07—11</strong><span>OCTOBER 2026</span><span class="field-place">Medulla · Berlin</span></div><div class="visit-main"><span class="visit-label">${esc(visit.status)}</span><h2 id="berlin-visit-title">${esc(visit.title)}</h2><div class="visit-body"><p>${ko?`방문 기간 중 사흘 동안 세 가지 일정을 진행합니다. 먼저 Fuzzy Ruling Spaces와 기계 지원 다자간 합의(Machine-Assisted Multi-Party Agreement)를 다룬 테크니컬 화이트페이퍼를 함께 리뷰합니다. 이어서 Civic Ledger의 기능 단위를 바탕으로 맥락, 도메인, 리드 마켓별 프로토타이핑을 진행하고, 마지막으로 베를린 시빅테크 해커톤에 참여합니다.`:`Over three days of the visit, we will review our technical white papers on Fuzzy Ruling Spaces and Machine-Assisted Multi-Party Agreement, prototype with Civic Ledger's functional units across contexts, domains and lead markets, and join a Berlin-based civic tech hackathon.`}</p></div></div><aside class="visit-detail"><div class="visit-actions"><button type="button" data-visit-contact aria-expanded="false" aria-controls="visit-contact-email">${esc(visit.contact)} ↗</button><a id="visit-contact-email" hidden href="mailto:civicledger@darkmatterlabs.org?subject=${encodeURIComponent('Berlin · 7–11 October 2026')}">civicledger@darkmatterlabs.org</a></div></aside></section>
  <section class="berlin-field-note" aria-labelledby="berlin-learning-title"><div class="field-stamp"><span class="micro">${ko?'최근 현장 기록':'Recent field notes'}</span><strong>03—05</strong><span>AUGUST 2026</span><span class="field-place">Medulla · Berlin</span></div><div class="field-story"><span class="visit-label">${ko?'작업 세션과 공개 대화':'Working sessions & public conversation'}</span><h2 id="berlin-learning-title">${ko?'베를린, 8월의 학습 기록.':'Berlin, August learnings.'}</h2><p>${ko?'<a href="https://www.politicsfortomorrow.eu" target="_blank" rel="noopener noreferrer">Politics for Tomorrow</a>와 함께 준비한 베를린 작업 세션에서는 데이터, 운영 주체, 라이선싱을 중심으로 시민 인프라가 파일럿 이후에도 지속되기 위한 조건을 탐구했습니다.':'Developed with <a href="https://www.politicsfortomorrow.eu" target="_blank" rel="noopener noreferrer">Politics for Tomorrow</a>, the Berlin working sessions explored data, organisational stewardship and licensing: the conditions for civic infrastructure to continue beyond a pilot.'}</p><h3>${ko?'무엇을 함께 이야기했나':'What the conversation opened up'}</h3><p>${ko?'8월 4일 공개 저녁 모임은 프로젝트 소개와 라이브 데모에 이어 참가자들이 둘러앉아 질문을 나누는 방식으로 진행됐습니다. 공공공간의 자발적 사용, AI가 판단을 돕는 범위, 데이터와 언어가 선택지를 만드는 방식, 개방성과 지식재산의 관계가 대화의 주요 주제였습니다.':'At the public evening on 4 August, a project introduction and live demonstration led into a circle discussion. Participants raised questions about spontaneous uses of public space, the limits of AI decision support, how data and language shape options, and the relationship between openness and intellectual property.'}</p><p>${ko?'하나의 결론으로 정리하기보다 서로 다른 관점을 드러내고, 다음 작업에서 이어갈 질문을 남겼습니다.':'The discussion brought different perspectives into view and left questions to carry into the next stage of work, rather than settling on a single conclusion.'}</p></div><aside class="field-resources" aria-label="${ko?'준비 자료와 사후 기록':'Preparation and follow-up'}"><a class="field-resource" href="https://dark-matter-labs.github.io/civic-ledger-berlin-aug-2026-learnings/" ${ext}><span class="micro">${ko?'모임 후 · 다시 읽기':'After · reflections to revisit'}</span><strong>${ko?'대화와 학습 요약':'Discussion & learning summary'}&nbsp;<span aria-hidden="true">↗</span></strong><span>${ko?'이후에 정리한 베를린 학습 기록으로 이동합니다.':'Continue to the post-session Berlin learning notes.'}</span></a></aside></section>
  <section class="archive-section" id="project-archive" aria-labelledby="archive-title"><header class="archive-heading"><div><div class="section-kicker">ARCHIVE</div><h2 id="archive-title">${esc(w.title)}</h2><p>${esc(w.intro)}</p></div></header><div class="archive-tools"><div class="archive-filters" role="group" aria-label="${esc(w.title)}">${['all','interview','project'].map(type=>`<button type="button" data-update-filter="${type}" aria-pressed="${updateFilter===type}">${esc(w[type])}</button>`).join('')}</div>${searchField('update-search',updateQuery,w.search,'archive-search')}<span id="update-count" class="micro" aria-live="polite"></span></div><ul id="update-list" class="archive-link-list"></ul></section>

</div>`;
  renderUpdateList();$('update-search').addEventListener('input',e=>{updateQuery=e.target.value;syncSearchClear(e.target);renderUpdateList()});
 }
 function mountSectionEnd(){
  // Keep end controls out of the coloured footer, identically aligned in every section.
  document.querySelectorAll('[data-section-end]').forEach(el=>el.remove());
  const panel=document.querySelector('#main-content>.site-panel:not([hidden])');
  if(!panel)return;
  const row=document.createElement('nav');row.className='section-end-actions';row.dataset.sectionEnd='';
  row.setAttribute('aria-label',lang==='ko'?'페이지 이동':'Page navigation');
  if(panel.id==='catalogue-panel')row.innerHTML=`<a href="#glossary" data-end-glossary>${lang==='ko'?'용어 안내':'Glossary'}</a>`;
  row.insertAdjacentHTML('beforeend',`<a href="#top" data-top>${esc(t().top)}</a>`);
  const host=panel.querySelector(':scope>.shell');
  if(host)host.append(row);else{const shell=document.createElement('div');shell.className='shell section-end-shell';shell.append(row);panel.append(shell);}
 }
 function renderFooter(){
  const ext='target="_blank" rel="noopener noreferrer"';
  $('tools-apps').innerHTML=`<div class="shell"><section class="footer-contact" id="contact" aria-labelledby="contact-title"><header class="footer-contact-heading"><span class="micro">${lang==='ko'?'문의 · 협업':'Conversations & collaboration'}</span><h2 id="contact-title" lang="en">Contact</h2></header><div class="footer-contact-details"><p>${lang==='ko'?'연구, 협업, 지역에서의 적용에 관한 이야기를 기다립니다.':'For conversations about research, collaboration and local applications.'}</p><div class="contact-general"><a class="contact-email" href="mailto:civicledger@darkmatterlabs.org">civicledger@<wbr>darkmatterlabs.org</a><div class="contact-actions"><a href="mailto:civicledger@darkmatterlabs.org">${lang==='ko'?'일반 문의':'General enquiries'} <span aria-hidden="true">↗</span></a><button type="button" data-copy-contact>${lang==='ko'?'주소 복사':'Copy address'}</button></div></div></div><div class="contact-address"><div class="contact-meeting"><h3>${lang==='ko'?'30분 온라인 대화':'A 30-minute conversation'}</h3><p>${lang==='ko'?'연구·협업·지역 적용을 이야기하며, 데모와 관련 자료도 함께 살펴볼 수 있습니다.':'Discuss research, collaboration or a local application. We can walk through a demo and share relevant materials.'}</p><button type="button" class="contact-meeting-button footer-outline-button" data-open-meeting aria-haspopup="dialog">${lang==='ko'?'30분 미팅 제안':'Propose a 30-minute meeting'} <span aria-hidden="true">↗</span></button></div></div></section><div class="footer-tools-label micro">${esc(t().footerTitle.replace(/\.$/,''))}</div><div class="tools-grid"><section class="tool-block"><span class="micro">${esc(t().web)}</span><h3>${esc(t().webTitle)}</h3><p>${esc(t().webDesc)}</p><div class="tool-links"><a href="https://civicledger.city" ${ext}>${esc(t().openWeb)}</a></div></section><section class="tool-block"><span class="micro">${esc(t().beta)}</span><h3>${esc(t().betaTitle)}</h3><p>${esc(t().betaDesc)}</p><div class="tool-links"><a href="https://www.wesharing.co.kr" ${ext}>${esc(t().betaWeb)}</a><a href="https://testflight.apple.com/join/KpGuvb5j" ${ext}>${esc(t().ios)}</a><a href="https://drive.google.com/file/d/1_1rBx58juQtROeDHDBSRCOIA6aMFWmJN/view?usp=drive_link" ${ext}>${esc(t().android)}</a></div><p class="link-note">${esc(t().betaNote)}</p></section><section class="tool-block"><span class="micro">${esc(t().builders)}</span><h3>${esc(t().buildersTitle)}</h3><p>${esc(t().buildersDesc)}</p><div class="tool-links"><a href="${routeLink('catalogue')}">${esc(t().browse)}</a></div></section></div><section class="footer-contributors" aria-labelledby="footer-contributors-title"><div><h2 id="footer-contributors-title">${lang==='ko'?'함께한 사람들':'Contributors'}</h2><p class="contributor-preview">${(DATA.contributors?.preview||[]).map(id=>{const person=DATA.contributors.groups.flatMap(g=>g.items).find(x=>x.id===id);return person.linkedin?`<a class="team-name-link" href="${esc(person.linkedin)}" target="_blank" rel="noopener noreferrer">${esc(person.name[lang]||person.name.en)}</a>`:`<span class="team-name">${esc(person.name[lang]||person.name.en)}</span>`}).join('<span aria-hidden="true"> · </span>')}</p></div><button type="button" class="contributors-open footer-outline-button" data-open-contributors aria-haspopup="dialog">${lang==='ko'?'자문·협력·지원 기관 보기':'View advisors, partners & supporters'} <span aria-hidden="true">↗</span></button></section><div class="beta-footer" lang="en"><p>© 2026 Civic Ledger · <a href="https://kr.darkmatterlabs.org/" target="_blank" rel="noopener noreferrer">Dark Matter Labs</a> · B.Builders · <a href="https://creativecommons.org/licenses/by-nc-nd/4.0/deed.en" target="_blank" rel="license noopener noreferrer">CC BY-NC-ND 4.0</a></p><a class="footer-top-link" href="#top" data-top lang="${lang}">${esc(t().top)}</a></div></div>`;
 }
 function setTheme(theme){currentTheme=theme==='dark'?'dark':'light';document.documentElement.dataset.theme=currentTheme;$('site-theme').setAttribute('aria-pressed',String(currentTheme==='dark'));try{localStorage.setItem('civic-journal-theme-v8',currentTheme)}catch(_){}if(catalogueReady)window.CivicCatalogue.applyTheme(currentTheme)}
 function route({keepScroll=false}={}){
  const sharedQuery=new URLSearchParams(location.search);const raw=location.hash.slice(1)||(sharedQuery.get('article')?'article/'+sharedQuery.get('article')+'?lang='+(sharedQuery.get('lang')||lang):(document.body.dataset.defaultRoute||'writing'));const [path,params='']=raw.split('?');const p=new URLSearchParams(params);
  const chosen=p.get('lang');if(chosen==='en'||chosen==='ko')lang=chosen;
  const active=path.startsWith('article/')?'writing':['writing','catalogue','events'].includes(path)?path:'writing';
  const articleId=path.startsWith('article/')?path.split('/')[1]:null;
  if(articleId&&!DATA.articles[articleId+'-'+lang]){location.hash=routeLink('writing');return;}
  if(readerCleanup&&!articleId){readerCleanup();readerCleanup=null;$('article-content').innerHTML='';}
  document.body.dataset.section=active;
  setLabels();
  document.querySelectorAll('[data-main-route]').forEach(a=>{const on=a.dataset.mainRoute===active;a.setAttribute('aria-selected',String(on));a.tabIndex=on?0:-1;});
  $('writing-panel').hidden=active!=='writing'||!!articleId;
  $('catalogue-panel').hidden=active!=='catalogue';$('events-panel').hidden=active!=='events';$('article-panel').hidden=!articleId;
  $('writing-tab').setAttribute('aria-controls',articleId?'article-panel':'writing-panel');
  if(articleId){$('article-panel').setAttribute('role','tabpanel');$('article-panel').setAttribute('aria-labelledby','writing-tab');}
  $('catalogue-language-note').hidden=true;$('catalogue-language-note').textContent=t().catalogueLanguage;
  if(articleId){renderArticle(articleId);document.title=DATA.articles[articleId+'-'+lang].title+' | Civic Ledger';}
  else if(active==='writing'){writingScaffold();document.title='Civic Ledger | '+t().writing;activeArticle=null;}
  else if(active==='catalogue'){initCatalogue();window.CivicCatalogue.readUrl();window.CivicCatalogue.setLocale(lang);document.title='Civic Ledger | '+t().catalogue;activeArticle=null;}
  else{renderEvents();document.title='Civic Ledger | '+t().events;activeArticle=null;}
  currentPage=articleId?'article/'+articleId:active;document.body.dataset.page=articleId?'article':active;if(!articleId)delete document.body.dataset.article;renderFooter();mountSectionEnd();
  if(!keepScroll)window.scrollTo({top:0,behavior:'instant'});
  if(active==='events'&&p.get('section')==='archive')requestAnimationFrame(()=>$('project-archive')?.scrollIntoView({block:'start',behavior:'instant'}));
  document.dispatchEvent(new Event('civic:route'));
 }
 function notify(text){const e=$('toast');e.textContent=text;e.hidden=false;clearTimeout(notify.timer);notify.timer=setTimeout(()=>e.hidden=true,3000)}
 // Source-image viewer. All images remain source assets, never reconstructed.
 let mediaZoom=1,baseWidth=0,mediaRatio=1,previousFocus=null,drag=null;
 function setMediaZoom(value){
  mediaZoom=Math.max(1,Math.min(4,value));const pic=$('media-image'),vp=$('media-viewport');pic.style.width=(baseWidth*mediaZoom)+'px';pic.style.height=(baseWidth*mediaZoom/mediaRatio)+'px';$('media-scale').textContent=Math.round(mediaZoom*100)+'%';$('media-out').disabled=mediaZoom===1;$('media-in').disabled=mediaZoom===4;
 }
 function fitMedia(){const pic=$('media-image'),vp=$('media-viewport');mediaRatio=pic.naturalWidth/pic.naturalHeight;baseWidth=Math.min(vp.clientWidth-24,(vp.clientHeight-24)*mediaRatio,pic.naturalWidth);setMediaZoom(1);vp.scrollTo(0,0)}
 function openMedia(key,title,source){if(!img(key))return;previousFocus=document.activeElement;$('media-title').textContent=title||t().inspect;$('media-source').textContent=source??'';const pic=$('media-image');pic.onload=()=>requestAnimationFrame(fitMedia);pic.src=img(key);pic.alt=title||t().inspect;$('media-dialog').showModal();document.body.style.overflow='hidden';requestAnimationFrame(()=>{if(pic.complete)fitMedia();$('media-close').focus()});}
 $('media-in').onclick=()=>setMediaZoom(mediaZoom+.5);$('media-out').onclick=()=>setMediaZoom(mediaZoom-.5);$('media-fit').onclick=fitMedia;$('media-close').onclick=()=>$('media-dialog').close();
 $('media-dialog').addEventListener('close',()=>{document.body.style.overflow='';previousFocus?.focus()});
 $('media-dialog').addEventListener('click',e=>{if(e.target===$('media-dialog')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close()}});
 $('media-dialog').addEventListener('keydown',e=>{if(['+','='].includes(e.key)){e.preventDefault();setMediaZoom(mediaZoom+.5)}if(e.key==='-'){e.preventDefault();setMediaZoom(mediaZoom-.5)}if(e.key==='0'){e.preventDefault();fitMedia()}});
 $('media-viewport').addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse'||e.button!==0)return;drag={x:e.clientX,y:e.clientY,left:e.currentTarget.scrollLeft,top:e.currentTarget.scrollTop};e.currentTarget.setPointerCapture(e.pointerId)});
 $('media-viewport').addEventListener('pointermove',e=>{if(!drag)return;e.currentTarget.scrollLeft=drag.left-(e.clientX-drag.x);e.currentTarget.scrollTop=drag.top-(e.clientY-drag.y)});
 for(const name of ['pointerup','pointercancel'])$('media-viewport').addEventListener(name,()=>drag=null);
 window.addEventListener('resize',()=>{if($('media-dialog').open)fitMedia()});
 document.addEventListener('click',e=>{
  const control=e.target.closest('a,button');if(!control)return;
  if(control.hasAttribute('data-visit-contact')){const email=$('visit-contact-email');email.hidden=false;control.setAttribute('aria-expanded','true');return;}
  if(control.dataset.clearSearch){const input=$(control.dataset.clearSearch);if(input){input.value='';input.dispatchEvent(new Event('input',{bubbles:true}));input.focus();}return;}
  if(control.dataset.lang){const chosen=control.dataset.lang;if(chosen===lang)return;window.CivicReaderUI?.rememberLanguagePosition();lang=chosen;const [base,q='']=(location.hash.slice(1)||document.body.dataset.defaultRoute||'writing').split('?');const p=new URLSearchParams(q);p.set('lang',lang);p.delete('p');p.delete('quote');location.hash=base+'?'+p;return;}
  if(control.dataset.writingFilter){filter=control.dataset.writingFilter;document.querySelectorAll('[data-writing-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.writingFilter===filter)));renderWriting();return;}
  if(control.dataset.updateFilter){updateFilter=control.dataset.updateFilter;renderUpdateList();document.querySelectorAll('[data-update-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.updateFilter===updateFilter)));return;}
  if(control.hasAttribute('data-open-berlin-prep')){e.preventDefault();const details=$('berlin-preparation')?.querySelector('details');if(details){details.open=true;details.scrollIntoView({block:'start',behavior:'smooth'});details.querySelector('summary')?.focus({preventScroll:true});}return;}
  if(control.hasAttribute('data-berlin-calendar')){downloadBerlinVisit();return;}
  if(control.dataset.media){openMedia(control.dataset.media,control.dataset.mediaTitle,control.dataset.mediaSource);return;}
  if(control.dataset.readerAnchor){e.preventDefault();const target=$('article-content').querySelector('#'+control.dataset.readerAnchor);if(innerWidth<=720)$('article-content').querySelector('.source-contents').open=false;target?.scrollIntoView({block:'start',behavior:'smooth'});return;}
  if(control.hasAttribute('data-end-glossary')){e.preventDefault();const target=$('catalogue-root')?.querySelector('#glossary');if(target){target.setAttribute('tabindex','-1');target.focus({preventScroll:true});target.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}return;}
  if(control.hasAttribute('data-top')){e.preventDefault();document.querySelector('#main-content')?.focus({preventScroll:true});window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});return;}
  if(control.hasAttribute('data-apps-jump')){e.preventDefault();$('tools-apps').scrollIntoView({block:'start',behavior:'smooth'});return;}
 });
 $('site-theme').addEventListener('click',()=>setTheme(currentTheme==='dark'?'light':'dark'));
 document.querySelector('.primary-nav').addEventListener('keydown',e=>{
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
  const links=[...e.currentTarget.querySelectorAll('a')];const i=links.indexOf(document.activeElement);if(i<0)return;e.preventDefault();const n=e.key==='Home'?0:e.key==='End'?links.length-1:(i+(e.key==='ArrowRight'?1:-1)+links.length)%links.length;links[n].focus();links[n].click();
 });
 window.addEventListener('hashchange',()=>route());
 setTheme(currentTheme);route();
 window.CivicJournal={navigate:route, get language(){return lang},get currentArticle(){return activeArticle},get summaries(){return copy[lang].summaries},data:DATA};
})();

;
/* v11: display and navigation only. Original article text and image data stay in content.json. */
'use strict';
(() => {
 const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
 const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const ko = () => document.documentElement.lang === 'ko';
 const language = () => ko()?'ko':'en';
 const href = route => '#'+route+'?lang='+language();
 const reduce = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
 let heads=[], active=null, pending=null, scheduled=false, lastKey='', mountToken=0;
 const sizes={en:null,ko:null};
 for(const l of ['en','ko']) {
  try {const n=Number(localStorage.getItem('civic-reading-size-'+l)); if(n>=16&&n<=24)sizes[l]=n;}catch(_){}
 }
 // Migrate an earlier Korean-only reader preference without changing saved notes.
 try { if(!sizes.ko) {const n=Number(localStorage.getItem('civic-ko-reading-size'));if(n>=16&&n<=22)sizes.ko=n;} }catch(_){}
 const words = () => ko()?{
  index:'전체 글',contents:'목차',settings:'읽기 설정',font:'본문 글자 크기',smaller:'글자 작게',larger:'글자 크게',reset:'기본 크기',progress:'읽은 분량',jump:'소제목으로 이동',prev:'이전 글',next:'다음 글',series:'시리즈 이어 읽기',all:'전체 글 보기',soon:'다음 주제 · 공개 예정',copied:'이메일 주소를 복사했습니다.',failed:'이메일 주소를 선택해 복사해 주세요.',note:'주석',topics:['허가','대화','신뢰'],ord:['첫 번째 글','두 번째 글','세 번째 글']
 }:{index:'All writing',contents:'Contents',settings:'Reading settings',font:'Body text size',smaller:'Smaller text',larger:'Larger text',reset:'Reset',progress:'Read',jump:'Jump to a section',prev:'Previous essay',next:'Next essay',series:'Continue the series',all:'All writing',soon:'Coming next',copied:'Email address copied.',failed:'Select the email address to copy it.',note:'Note',topics:['Permission','Dialogue','Trust'],ord:['First essay','Second essay','Third essay']};
 const label=id=>id==='paper1'?(ko()?'기술 백서 1':'Technical paper 1'):id==='paper2'?(ko()?'기술 백서 아티클 2':'Technical paper article 2'):([...(ko()?['첫 번째 글','두 번째 글','세 번째 글','네 번째 글','다섯 번째 글']:['First essay','Second essay','Third essay','Fourth essay','Fifth essay'])][Number(id)-1]||'');
 const finalArticle=id=>window.CivicJournal?.data.articles[id+'-'+language()];
 const seriesNeighbours=id=>{const order=(id.startsWith('paper')?window.CivicJournal.data.technicalOrder:window.CivicJournal.data.seriesOrder)||['1','2','3','4'];const i=order.indexOf(String(id));return {prev:i>0?order[i-1]:null,next:i>=0&&i<order.length-1?order[i+1]:null};};
 const defaultSize=()=>ko()?(innerWidth<=720?17:18):(innerWidth<=720?18:19);
 function notify(message) {const el=$('#toast');if(!el)return;el.textContent=message;el.hidden=false;clearTimeout(notify.timer);notify.timer=setTimeout(()=>el.hidden=true,2800);}
 function offset(){return ($('.site-header')?.getBoundingClientRect().height||0)+($('.reader-bar')?.getBoundingClientRect().height||0)+20;}
 const sourceKeys={
  '2-en':['overview','positions','protocol','loop','loop-overview','step-1','step-2','step-3','step-4','step-5','technology','rule-engine','conversation','assets','conclusion','credits','partners','authors'],
  '2-ko':['overview','positions','protocol','loop','step-1','step-2','step-3','step-4','step-5','technology','rule-engine','conversation','assets','conclusion','credits','partners','authors','project-note'],
  '3-en':['overview','trust-conditions','principle-1','principle-2','principle-3','principle-4','boundaries','conclusion','credits','partners','authors'],
  '3-ko':['overview','trust-conditions','principle-1','principle-2','principle-3','principle-4','boundaries','conclusion','credits','partners','authors','project-note','references']
 };
 function makeHeadings(root,id){
  if(id==='1')return [...root.querySelectorAll('.section[id],.endmatter[id]')].map(e=>({key:e.dataset.readKey||e.id,id:e.id,text:e.querySelector('h2')?.textContent.trim()||'',node:e,level:1})).filter(h=>h.text);
  return [...root.querySelectorAll('.source-prose h2,.source-prose h3')].map(node=>{
   const key=node.dataset.readKey||node.id,child=node.tagName==='H3';
   node.classList.toggle('reader-subheading',child);node.setAttribute('aria-level',child?'3':'2');
   return {key,id:node.id,text:node.textContent.trim(),node,level:child?2:1};
  });
 }
 function decorateArticle(root,id){
  const a=finalArticle(id);
  if(id!=='1'){const kick=root.querySelector('.source-title .section-kicker');if(kick)kick.textContent=a.collection==='technical'?a.collectionLabel:'Civic Ledger · '+label(id)+' · '+a.topic;return;}
  root.querySelectorAll('.chapter-no,.issue-index,.folio').forEach(e=>e.remove());
  const issue=root.querySelector('.issue-label');if(issue)issue.textContent=label(id)+' · '+a.topic;
  root.querySelector('.hero-baseline > span')?.remove();
 }
 function sizeUI(){
  if(!active)return;
  const root=$('#article-content'), n=sizes[language()]||defaultSize();
  root.style.setProperty('--reading-size',n+'px');
  const out=$('#reader-size');if(out)out.textContent=n+' px';
  const minus=$('[data-reader-size="-1"]'),plus=$('[data-reader-size="1"]');
  if(minus)minus.disabled=n<=16;if(plus)plus.disabled=n>=24;
 }
 function drawNavigation(root,id){
  const w=words();
  const bar=document.createElement('nav');bar.className='reader-bar';bar.setAttribute('aria-label',ko()?'글 읽기와 이동':'Article navigation');
  bar.innerHTML=`<div class="reader-bar-inner"><div class="reader-location"><a class="back-index" href="${href('writing')}">← ${esc(w.index)}</a><span class="reader-location-divider" aria-hidden="true">/</span><span class="reader-current-essay">${esc(label(id))}</span></div><div class="reader-controls"><details class="reader-toc"><summary>${esc(w.contents)} <span aria-hidden="true">⌄</span></summary><div class="reader-popover toc-popover"><div class="toc-label">${esc(w.jump)}</div><div class="toc-scroll">${heads.map(h=>`<a class="toc-entry toc-level-${h.level}" href="#${esc(h.id)}" data-jump-key="${esc(h.key)}">${esc(h.text)}</a>`).join('')}</div><div class="reading-progress-label"><span>${esc(w.progress)}</span><span id="reading-progress-text">0%</span></div><div class="reading-progress-track" aria-hidden="true"><span id="reading-progress-fill"></span></div></div></details><details class="reader-settings"><summary>${esc(w.settings)} <span aria-hidden="true">⌄</span></summary><div class="reader-popover settings-popover"><span class="toc-label">${esc(w.font)}</span><div class="font-size-controls"><button type="button" data-reader-size="-1" aria-label="${esc(w.smaller)}">A−</button><output id="reader-size" aria-live="polite"></output><button type="button" data-reader-size="1" aria-label="${esc(w.larger)}">A+</button></div><button type="button" class="reader-reset" data-reader-reset>${esc(w.reset)}</button><div class="reader-notes-slot"></div></div></details></div></div>`;
  $('#article-panel').prepend(bar);
  const neighbours=seriesNeighbours(id);const isReady=n=>n&&finalArticle(n)?.status!=='forthcoming';const seriesLinks=document.createElement('div');seriesLinks.className='toc-series-links';
  seriesLinks.innerHTML=`${isReady(neighbours.prev)?`<a href="${href('article/'+neighbours.prev)}" title="${esc(finalArticle(neighbours.prev).title)}">← ${esc(w.prev)}</a>`:`<a href="${href('writing')}">${esc(w.index)}</a>`}${isReady(neighbours.next)?`<a href="${href('article/'+neighbours.next)}" title="${esc(finalArticle(neighbours.next).title)}">${esc(w.next)} →</a>`:`<a href="${href('writing')}">${esc(w.all)} →</a>`}`;
  bar.querySelector('.toc-popover').append(seriesLinks);
  // Reuse the first essay's existing notes toggle and listener.
  const notes=root.querySelector('#notesToggle');if(notes)bar.querySelector('.reader-notes-slot').append(notes);
  else bar.querySelector('.reader-notes-slot').remove();
  bar.querySelectorAll('details').forEach(d=>d.addEventListener('toggle',()=>{
   if(d.open)bar.querySelectorAll('details').forEach(other=>{if(other!==d)other.open=false;});
  }));
  // Destination titles are visible; bare counters do not carry navigation meaning.
  const old=$('#article-tail .article-bottom-links');if(old)old.remove();
  const tail=document.createElement('nav');tail.className='shell article-pagination';tail.setAttribute('aria-label',esc(w.series));
  const title=n=>finalArticle(n).title;
  const prevLink=neighbours.prev&&!isReady(neighbours.prev)?`<div class="pagination-link prev is-forthcoming"><span class="pagination-label">${esc(label(neighbours.prev))} · ${ko()?'공개 예정':'Forthcoming'}</span><strong>${esc(title(neighbours.prev))}</strong></div>`:neighbours.prev?`<a class="pagination-link prev" href="${href('article/'+neighbours.prev)}" rel="prev"><span class="pagination-label">← ${esc(w.prev)} · ${esc(label(neighbours.prev))}</span><strong>${esc(title(neighbours.prev))}</strong></a>`:`<a class="pagination-link prev" href="${href('writing')}"><span class="pagination-label">← ${esc(w.index)}</span><strong>${ko()?'모든 글 살펴보기':'Explore all writing'}</strong></a>`;
  const nextLink=neighbours.next&&!isReady(neighbours.next)?`<div class="pagination-link next is-forthcoming"><span class="pagination-label">${esc(label(neighbours.next))} · ${ko()?'공개 예정':'Forthcoming'}</span><strong>${esc(title(neighbours.next))}</strong><p>${esc(finalArticle(neighbours.next).description)}</p></div>`:neighbours.next?`<a class="pagination-link next" href="${href('article/'+neighbours.next)}" rel="next"><span class="pagination-label">${esc(w.next)} · ${esc(label(neighbours.next))} →</span><strong>${esc(title(neighbours.next))}</strong></a>`:id==='4'?`<div class="pagination-link next is-forthcoming"><span class="pagination-label">${esc(w.soon)}</span><strong>${ko()?'라이선스와 오픈 라이선스':'Licences and open licences'}</strong></div>`:`<a class="pagination-link next" href="${href('article/4')}"><span class="pagination-label">${ko()?'관련 글 · Civic Ledger 시리즈':'Related reading · Civic Ledger series'} →</span><strong>${esc(title('4'))}</strong></a>`;
  tail.innerHTML=`<div class="pagination-heading"><h2>${id==='paper2'?(ko()?'함께 읽기':'Related reading'):esc(w.series)}</h2><a href="${href('writing')}">${esc(w.all)} ↑</a></div><div class="pagination-grid">${prevLink}${nextLink}</div>${id==='4'?`<div class="technical-cross-reference"><span class="micro">${ko()?'시리즈와 별도로 읽기':'Alongside the series'}</span><a href="${href('article/paper2')}"><strong>${esc(title('paper2'))}</strong> ↗</a></div>`:''}`;
  $('#article-tail').append(tail);
 }
 function currentPosition(){
  if(!active||!heads.length)return null;
  const y=scrollY+offset();let index=-1;
  heads.forEach((h,i)=>{if(h.node.getBoundingClientRect().top+scrollY<=y+5)index=i;});
  if(index<0)return {article:active,key:'top',fraction:0};
  const from=heads[index].node.getBoundingClientRect().top+scrollY;
  const to=heads[index+1]?.node.getBoundingClientRect().top+scrollY||$('#article-content').getBoundingClientRect().bottom+scrollY;
  return {article:active,key:heads[index].key,fraction:Math.max(0,Math.min(.98,(y-from)/Math.max(1,to-from)))};
 }
 function restorePosition(pos){
  if(!pos||pos.article!==active)return;
  if(pos.key==='top'){scrollTo({top:0,behavior:'instant'});return;}
  const index=heads.findIndex(h=>h.key===pos.key);if(index<0)return;
  const start=heads[index].node.getBoundingClientRect().top+scrollY;
  const end=heads[index+1]?.node.getBoundingClientRect().top+scrollY||$('#article-content').getBoundingClientRect().bottom+scrollY;
  scrollTo({top:Math.max(0,start+(end-start)*(pos.fraction||0)-offset()),behavior:'instant'});
  updateReading();
 }
 function updateReading(){
  scheduled=false;if(!active||!heads.length)return;
  const pos=currentPosition();const key=pos?.key;
  if(key!==lastKey){
   $$('.toc-entry').forEach(e=>{if(e.dataset.jumpKey===key)e.setAttribute('aria-current','location');else e.removeAttribute('aria-current');});lastKey=key;
  }
  const first=heads[0].node.getBoundingClientRect().top+scrollY;
  const end=$('#article-content').getBoundingClientRect().bottom+scrollY;
  const percent=Math.round(Math.max(0,Math.min(100,(scrollY+offset()-first)/Math.max(1,end-first-innerHeight+offset())*100)));
  const progress=$('#reading-progress-text'),fill=$('#reading-progress-fill');if(progress)progress.textContent=percent+'%';if(fill)fill.style.width=percent+'%';
 }
 function jump(key){
  const h=heads.find(h=>h.key===key);if(!h)return;
  $$('.reader-bar details').forEach(d=>d.open=false);
  // Replace, rather than remount the article: highlights and selections remain intact.
  const [path,query='']=location.hash.slice(1).split('?');const params=new URLSearchParams(query);params.set('at',key);params.delete('p');params.delete('quote');
  try{history.replaceState(null,'','#'+path+'?'+params);}catch(_){}
  const target=h.node.getBoundingClientRect().top+scrollY-offset();scrollTo({top:target,behavior:'instant'});
  h.node.setAttribute('tabindex','-1');h.node.focus({preventScroll:true});
 }
 function mount(){
  const token=++mountToken;$('.reader-bar')?.remove();heads=[];lastKey='';
  const id=window.CivicJournal?.currentArticle;
  active=id?String(id):null;
  const brand=$('.site-brand');if(brand){brand.href=href('writing');brand.setAttribute('aria-label',ko()?'Civic Ledger · 전체 글':'Civic Ledger · All writing');}
  $('.wordmark-rule')?.remove();
  $$('.language-switch button').forEach(b=>{b.textContent=b.dataset.lang==='en'?'English':'한국어';b.lang=b.dataset.lang;b.title=b.dataset.lang==='en'?'Read in English':'한국어로 읽기';b.setAttribute('aria-label',b.title);});
  const mode=$('#site-theme');if(mode){mode.title=ko()?'밝은 화면 / 어두운 화면':'Light / dark appearance';mode.setAttribute('aria-label',mode.title);}
  if(!active||finalArticle(active)?.status==='forthcoming'){active=null;pending=null;return;}
  const root=$('#article-content');decorateArticle(root,active);heads=makeHeadings(root,active);drawNavigation(root,active);sizeUI();
  const prior=pending;pending=null;
  const params=new URLSearchParams(location.hash.split('?')[1]||'');
  const at=prior?.key||params.get('at');
  if(at){const pos=prior||{article:active,key:at,fraction:0};requestAnimationFrame(()=>requestAnimationFrame(()=>{if(token===mountToken)restorePosition(pos);}));}
  else requestAnimationFrame(updateReading);
 }
 async function copyContact(){
  const address='civicledger@darkmatterlabs.org';let ok=false;
  try{await navigator.clipboard.writeText(address);ok=true;}catch(_){
   const t=document.createElement('textarea');t.value=address;t.style.cssText='position:fixed;top:0;left:-9999px';document.body.append(t);t.select();
   try{ok=document.execCommand('copy');}catch(_){}t.remove();
  }
  notify(ok?words().copied:words().failed);
 }
 document.addEventListener('click',e=>{
  const b=e.target.closest('a,button');
  if(b?.hasAttribute('data-copy-contact')){copyContact();return;}
  if(b?.dataset.jumpKey){e.preventDefault();jump(b.dataset.jumpKey);return;}
  if(b?.hasAttribute('data-reader-size')||b?.hasAttribute('data-reader-reset')){
   const prior=currentPosition();
   sizes[language()]=b.hasAttribute('data-reader-reset')?null:Math.max(16,Math.min(24,(sizes[language()]||defaultSize())+Number(b.dataset.readerSize)));
   try{if(sizes[language()])localStorage.setItem('civic-reading-size-'+language(),sizes[language()]);else {localStorage.removeItem('civic-reading-size-'+language());if(ko())localStorage.removeItem('civic-ko-reading-size');}}catch(_){}
   sizeUI();requestAnimationFrame(()=>restorePosition(prior));return;
  }
  if(!e.target.closest('.reader-bar'))$$('.reader-bar details').forEach(d=>d.open=false);
 });
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){$$('.reader-bar details[open]').forEach(d=>{d.open=false;d.querySelector('summary').focus();});}});
 window.addEventListener('scroll',()=>{if(!scheduled){scheduled=true;requestAnimationFrame(updateReading);}},{passive:true});
 window.addEventListener('resize',()=>{sizeUI();updateReading();});
 document.addEventListener('civic:route',mount);
 window.CivicReaderUI={rememberLanguagePosition(){pending=currentPosition();},getPosition:currentPosition};
 mount();
})();

;
/* Text-only contributor directory. The complete list is shown, without search.
 * Names, roles and verified profile links are edited in contributors.json. */
(() => {
 'use strict';
 const data=window.CivicJournal.data.contributors;
 if(!data)return;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const locale=()=>window.CivicJournal.language==='ko'?'ko':'en';
 const text=v=>v?.[locale()]||v?.en||'';
 const dialog=document.createElement('dialog');
 dialog.id='contributors-dialog';dialog.className='contributors-dialog';
 dialog.setAttribute('aria-labelledby','contributors-title');document.body.append(dialog);
 let returnFocus=null,oldOverflow='';
 function open(trigger){
  if(dialog.open)return;
  const ko=locale()==='ko';returnFocus=trigger;dialog.lang=locale();
  const groups=data.groups.filter(g=>g.id!=='team').map(g=>`<section class="contributor-group" aria-labelledby="cg-${esc(g.id)}"><h3 id="cg-${esc(g.id)}">${esc(text(g.title))}</h3><ul class="contributor-name-list">${g.items.map(p=>`<li data-contributor="${esc(p.id)}" tabindex="-1">${(p.linkedin||p.website)?`<a class="contributor-name person-profile-link" href="${esc(p.linkedin||p.website)}" target="_blank" rel="noopener noreferrer" aria-label="${esc(text(p.name))} · ${p.linkedin?'LinkedIn':'Website'}">${esc(text(p.name))}<span class="profile-indicator" aria-hidden="true">↗</span></a>`:`<span class="contributor-name">${esc(text(p.name))}</span>`}${p.role?`<span class="contributor-role">${p.affiliationUrl?`<a href="${esc(p.affiliationUrl)}" target="_blank" rel="noopener noreferrer">${esc(text(p.role))}</a>`:esc(text(p.role))}</span>`:''}</li>`).join('')}</ul></section>`).join('');
  dialog.innerHTML=`<header class="contributors-heading"><div><span class="contributors-kicker">Civic Ledger</span><h2 id="contributors-title">${ko?'자문·협력·지원 기관':'Advisors, partners & supporters'}</h2><p>${ko?'전략 자문 · 협력·지원 기관':'Strategic advisors · Partner & supporting institutions'}</p></div><button type="button" class="contributors-close" data-close-contributors aria-label="${ko?'닫기':'Close'}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg></button></header><div class="contributors-scroll" id="contributors-scroll"><div id="contributors-list">${groups}</div></div>`;
  oldOverflow=document.body.style.overflow;document.body.style.overflow='hidden';
  dialog.showModal();dialog.querySelector('[data-close-contributors]').focus({preventScroll:true});
  requestAnimationFrame(()=>{
   const person=trigger?.dataset.contributorPerson;
   const group=trigger?.dataset.contributorFocus;
   const target=person?dialog.querySelector(`[data-contributor="${CSS.escape(person)}"]`):group?dialog.querySelector('#cg-'+CSS.escape(group)):null;
   if(target){target.scrollIntoView({block:'nearest',behavior:'instant'});target.classList.add('contributor-selected');}
  });
 }
 document.addEventListener('click',e=>{const b=e.target.closest('[data-open-contributors]');if(b){e.preventDefault();open(b);}});
 dialog.addEventListener('click',e=>{
  if(e.target.closest('[data-close-contributors]'))dialog.close();
  if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}
 });
 dialog.addEventListener('close',()=>{document.body.style.overflow=oldOverflow;if(returnFocus?.isConnected)returnFocus.focus({preventScroll:true});returnFocus=null;});
 document.addEventListener('civic:route',()=>{if(dialog.open)dialog.close();});
})();

;
/* v13: visual geometry only. No text or reader-storage migration. */
(() => {
 'use strict';
 const root=document.documentElement;
 let raf=0;
 const observe=new ResizeObserver(()=>queueMeasure());
 const watched=new WeakSet();
 function watch(el){if(el&&!watched.has(el)){watched.add(el);observe.observe(el);}}
 function measure(){
  raf=0;
  const header=document.querySelector('.site-header');
  const reader=document.querySelector('.reader-bar');
  if(header){const h=Math.ceil(header.getBoundingClientRect().height);if(h>0&&root.style.getPropertyValue('--header-h')!==h+'px')root.style.setProperty('--header-h',h+'px');}
  if(reader){const h=Math.ceil(reader.getBoundingClientRect().height);if(h>0)root.style.setProperty('--reader-bar-h',h+'px');}
  watch(header);watch(reader);
 }
 function queueMeasure(){if(!raf)raf=requestAnimationFrame(measure);}
 function arrange(){
  // The catalogue toolbar follows its introduction. It is not a second fixed
  // header covering the introduction during navigation or viewport changes.
  const cat=document.querySelector('#catalogue-root');
  const intro=cat?.querySelector('.intro'), toolbar=cat?.querySelector('.topbar');
  if(intro&&toolbar&&intro.nextElementSibling!==toolbar)intro.after(toolbar);
  queueMeasure();
 }
 document.addEventListener('civic:route',arrange);
 window.addEventListener('resize',queueMeasure,{passive:true});
 window.addEventListener('pageshow',queueMeasure);
 if(document.fonts)document.fonts.ready.then(queueMeasure);
 arrange();measure();
})();

;
/* v15: references use empty-text superscript links, preserving highlight offsets.
   Wide screens: one source rail. Narrow screens: an accessible source dialog.
   No source is assigned to a claim unless an explicit association is in the manuscript. */
(() => {
 'use strict';
 const $=s=>document.querySelector(s);
 const ko=()=>document.documentElement.lang==='ko';
 let lastFocus=null,activeRef=null;
 const dialog=document.createElement('dialog');dialog.id='reference-dialog';dialog.className='reference-dialog';
 dialog.setAttribute('aria-labelledby','reference-dialog-title');
 dialog.innerHTML='<header class="reference-dialog-head"><h2 id="reference-dialog-title"></h2><button type="button" data-close-references aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></header><div class="reference-dialog-body"></div>';
 document.body.append(dialog);
 function offset(){return ($('.site-header')?.getBoundingClientRect().height||0)+($('.reader-bar')?.getBoundingClientRect().height||0)+24;}
 function updateClone(){
  const rail=$('#article-content .reference-rail');if(!rail)return;
  const clone=rail.querySelector('.reference-rail-inner').cloneNode(true);
  clone.querySelector('.reference-rail-title')?.remove();
  clone.querySelectorAll('[id]').forEach(el=>{el.dataset.originalRef=el.id;el.id+='-dialog';});
  dialog.querySelector('.reference-dialog-body').replaceChildren(clone);
  $('#reference-dialog-title').textContent=ko()?'출처와 문헌':'Sources & reading';
  dialog.querySelector('[data-close-references]').setAttribute('aria-label',ko()?'출처 닫기':'Close sources');
 }
 function activate(id,modal=false){
  document.querySelectorAll('.reference-entry.is-active').forEach(el=>el.classList.remove('is-active'));
  const entry=document.getElementById(id+(modal?'-dialog':''));if(!entry)return;
  entry.classList.add('is-active');entry.scrollIntoView({block:'nearest',behavior:'instant'});entry.focus({preventScroll:true});
 }
 function openSources(id=null){
  lastFocus=document.activeElement;activeRef=id;updateClone();
  if(!dialog.open)dialog.showModal();
  document.body.classList.add('references-open');
  requestAnimationFrame(()=>{if(id)activate(id,true);else dialog.querySelector('[data-close-references]').focus();});
 }
 function closeSources(){if(dialog.open)dialog.close();}
 dialog.addEventListener('close',()=>{document.body.classList.remove('references-open');lastFocus?.focus({preventScroll:true});});
 dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeSources();}});
 document.addEventListener('click',e=>{
  const target=e.target.closest('[data-ref-target],[data-open-references],[data-ref-return],[data-close-references]');if(!target)return;
  e.preventDefault();e.stopImmediatePropagation();
  if(target.hasAttribute('data-close-references')){closeSources();return;}
  if(target.hasAttribute('data-open-references')){openSources();return;}
  if(target.dataset.refReturn){
   const marker=document.getElementById(target.dataset.refReturn);closeSources();
   if(marker){const top=marker.getBoundingClientRect().top+scrollY-offset();window.scrollTo({top:Math.max(0,top),behavior:'instant'});marker.focus({preventScroll:true});}
   return;
  }
  const id=target.dataset.refTarget;activeRef=id;lastFocus=target;
  if(matchMedia('(min-width:1120px)').matches)activate(id);else openSources(id);
 },true);
 function mount(){
  closeSources();$('.reader-sources-button')?.remove();activeRef=null;
  if(!window.CivicJournal?.currentArticle||!$('#article-content .reference-rail'))return;
  const controls=$('.reader-controls');if(!controls)return;
  const b=document.createElement('button');b.type='button';b.className='reader-sources-button';b.setAttribute('data-open-references','');b.setAttribute('aria-haspopup','dialog');b.textContent=ko()?'출처':'Sources';
  controls.insertBefore(b,controls.querySelector('.reader-settings'));
 }
 // Native dialogs remain usable during live resizing; the rail always uses normal flow.
 document.addEventListener('civic:route',mount);mount();
})();

;
/* 30-minute meeting proposals. No event is created by this static site.
   A verified Google appointment schedule URL, when supplied, takes precedence.
   A Calendar template is a draft in the visitor's own account, not a booking. */
(() => {
 'use strict';
 const conf=Object.assign({hostName:'Eunji Kang',hostEmail:'eunji@darkmatterlabs.org',durationMinutes:30,appointmentBookingUrl:''},window.CIVIC_READER_CONFIG?.meeting||{});
 const lang=()=>window.CivicJournal.language==='ko'?'ko':'en';
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const text={ko:{title:'30분 미팅 제안',note:'연구·협업·지역 적용에 관해 이야기하고, 데모와 관련 자료를 함께 살펴볼 수 있습니다.',notice:'선택하는 시간은 희망 시간입니다. 일정과 Google Meet 링크는 확인 후 초대에서 안내합니다.',name:'이름',email:'회신 이메일',zone:'표시 시간대',date:'희망 날짜',time:'시작 시간 · 30분',topic:'이야기하고 싶은 내용 (선택)',topicHint:'예: 도시 적용, 데모 요청, 연구 협업',calendar:'Google 캘린더에서 제안 준비 ↗',mail:'이메일로 제안 작성 ↗',copy:'제안 내용 복사',close:'닫기',ready:'날짜와 시간을 선택해 주세요.',invalid:'올바른 날짜, 시간과 시간대를 선택해 주세요.',past:'앞으로의 날짜와 시간을 선택해 주세요.',dst:'시간대 전환으로 중복되거나 존재하지 않는 시간입니다. 다른 시간을 선택해 주세요.',copied:'제안 내용을 복사했습니다. 아직 발송되거나 예약되지 않았습니다.',failed:'복사하지 못했습니다. 이메일 작성 버튼을 사용해 주세요.',draft:'외부 작성 창에서 내용을 확인해 주세요. 아직 예약이 확정된 것은 아닙니다.',book:'가능한 시간 선택 · Google 예약 일정 ↗',booknote:'공개된 예약 일정에서 시간을 선택합니다. 개인 캘린더 내용은 이 사이트에 표시하지 않습니다.',other:'또는 희망 시간을 직접 제안할 수 있습니다.',required:'이름과 회신 이메일을 입력해 주세요.',proposal:'Civic Ledger · 30분 미팅 제안',intro:'안녕하세요, 강은지 님. 아래 시간으로 30분 온라인 미팅을 제안드립니다.',ending:'데모와 관련 자료를 함께 살펴보고 싶습니다. 가능 여부와 Google Meet 초대를 회신 부탁드립니다.',preview:'희망 시간',utc:'협의 기준 (UTC)'},en:{title:'Propose a 30-minute meeting',note:'Discuss research, collaboration or a local application. We can walk through a demo and share relevant materials.',notice:'This is a proposed time, not confirmed availability. The time and Google Meet link will be confirmed in the invitation.',name:'Your name',email:'Reply email',zone:'Time zone',date:'Preferred date',time:'Start time · 30 minutes',topic:'What would you like to discuss? (optional)',topicHint:'For example: a city application, a demo or research collaboration',calendar:'Prepare in Google Calendar ↗',mail:'Prepare an email ↗',copy:'Copy proposal',close:'Close',ready:'Choose a date and time.',invalid:'Choose a valid date, time and time zone.',past:'Please choose a time in the future.',dst:'This time is repeated or does not exist because of a clock change. Please choose another time.',copied:'Proposal copied. Nothing has been sent or booked.',failed:'Copy failed. Please use the email option.',draft:'Review the details in the external compose window. This is not a confirmed booking.',book:'Choose an available time · Google booking page ↗',booknote:'Select a time on the published booking page. Private calendar details are not shown on this site.',other:'Or propose a different time below.',required:'Please enter your name and reply email.',proposal:'Civic Ledger · 30-minute meeting proposal',intro:'Hello Eunji, I would like to propose a 30-minute online meeting at the time below.',ending:'I would be glad to explore a demo and supporting materials. Please confirm the time and send a Google Meet invitation.',preview:'Proposed time',utc:'Reference time (UTC)'}};
 // Host routing is an explicit topic choice, not an inference from personal data.
 const fallbackHosts={
  research:{name:{ko:'강은지',en:'Eunji Kang'},email:'eunji@darkmatterlabs.org',appointmentBookingUrl:''},
  technical:{name:{ko:'구재승',en:'Jaeseung Koo'},email:'koo@darkmatterlabs.org',appointmentBookingUrl:''}
 };
 const categories=[
  {id:'research',host:'research',ko:'연구 협업',en:'Research collaboration'},
  {id:'technical',host:'technical',ko:'기술 협업',en:'Technical collaboration'},
  {id:'pilot',host:'research',ko:'파일럿 · 현지 적용',en:'Pilot / local application'},
  {id:'partnership',host:'research',ko:'파트너십 · 기타 협업',en:'Partnership / other collaboration'}
 ];
 function category(id){return categories.find(c=>c.id===id)||categories[0];}
 function hostFor(id){
  const key=category(id).host, base=fallbackHosts[key],h=conf.hosts?.[key]||{};
  const email=typeof h.email==='string'&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(h.email)?h.email:base.email;
  return {...base,...h,email,name:typeof h.name==='object'?{...base.name,...h.name}:base.name};
 }
 function hostName(host){return host.name[lang()]||host.name.en;}
 function selectedCategory(){return dialog.querySelector('[name="category"]')?.value||'research';}
 function updateHost(){
  const host=hostFor(selectedCategory()),w=labels(),el=dialog.querySelector('#meeting-recipient');
  el.innerHTML=`<span class="meeting-recipient-label">${lang()==='ko'?'미팅 담당':'Meeting with'}</span><strong>${esc(hostName(host))}</strong><a href="mailto:${esc(host.email)}">${esc(host.email)}</a>`;
  const direct=dialog.querySelector('#meeting-direct'),url=bookingUrl(selectedCategory());
  direct.hidden=!url;
  direct.innerHTML=url?`<a class="booking-official" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(w.book)}</a><small>${esc(w.booknote)}</small>`:'';
 }
 const dialog=document.createElement('dialog');dialog.id='meeting-dialog';dialog.className='meeting-dialog';dialog.setAttribute('aria-labelledby','meeting-title');document.body.append(dialog);
 let back=null,overflow='';
 const formatter=zone=>new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
 const parts=(date,zone)=>Object.fromEntries(formatter(zone).formatToParts(date).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));
 const clockNumber=(date,zone)=>{const p=parts(date,zone);return Date.UTC(+p.year,+p.month-1,+p.day,+p.hour,+p.minute,+p.second);};
 function zonedTime(date,time,zone){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!/^\d{2}:\d{2}$/.test(time))return null;
  const [y,m,d]=date.split('-').map(Number),[h,min]=time.split(':').map(Number);
  if(h>23||min>59)return null;
  const expected=Date.UTC(y,m-1,d,h,min,0);const check=new Date(expected);
  if(check.getUTCFullYear()!==y||check.getUTCMonth()!==m-1||check.getUTCDate()!==d)return null;
  let guess=expected;
  try{for(let i=0;i<4;i++)guess+=expected-clockNumber(new Date(guess),zone);
   const candidates=[...new Set([0,-7200000,-3600000,-1800000,1800000,3600000,7200000].map(x=>guess+x))].filter(x=>clockNumber(new Date(x),zone)===expected);
   return candidates.length===1?new Date(candidates[0]):'dst';
  }catch(_){return null;}
 }
 function bookingUrl(id='research'){try{const h=hostFor(id),raw=h.appointmentBookingUrl||(category(id).host==='research'?conf.appointmentBookingUrl:'');const u=new URL(raw);return u.protocol==='https:'&&['calendar.google.com','calendar.app.google'].includes(u.hostname)?u.href:'';}catch(_){return '';}}
 function labels(){return text[lang()];}
 function zones(){let z=[];try{z=Intl.supportedValuesOf('timeZone');}catch(_){}const local=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';return {local,values:[...new Set([local,'Asia/Seoul','Europe/Berlin','Europe/London','America/New_York','America/Los_Angeles','Australia/Melbourne','UTC',...z]) ]};}
 function open(trigger){
  if(dialog.open)return;back=trigger;overflow=document.body.style.overflow;document.body.style.overflow='hidden';dialog.lang=lang();
  const w=labels(),zoneList=zones();
  dialog.innerHTML=`<header class="meeting-dialog-heading"><div><span class="micro">Civic Ledger</span><h2 id="meeting-title">${esc(w.title)}</h2></div><button type="button" class="meeting-close" data-close-meeting aria-label="${esc(w.close)}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></header><div class="meeting-body"><p>${esc(w.note)}</p><div class="meeting-direct" id="meeting-direct" hidden></div><p class="meeting-proposal-notice">${esc(w.notice)}</p><form class="meeting-form" id="meeting-form"><div class="meeting-route-row"><label class="meeting-field">${lang()==='ko'?'대화 주제':'Conversation topic'}<select name="category">${categories.map(c=>`<option value="${c.id}">${esc(c[lang()])}</option>`).join('')}</select></label><div id="meeting-recipient" class="meeting-recipient" aria-live="polite"></div></div><label class="meeting-field">${esc(w.name)}<input name="name" autocomplete="name" maxlength="100" required></label><label class="meeting-field">${esc(w.email)}<input name="email" type="email" autocomplete="email" maxlength="200" required></label><label class="meeting-field wide">${esc(w.zone)}<select name="zone">${zoneList.values.map(z=>`<option value="${esc(z)}" ${z===zoneList.local?'selected':''}>${esc(z.replace(/_/g,' '))}</option>`).join('')}</select></label><label class="meeting-field">${esc(w.date)}<input name="date" type="date" required></label><label class="meeting-field">${esc(w.time)}<input name="time" type="time" step="900" required></label><label class="meeting-field wide">${esc(w.topic)}<textarea name="topic" maxlength="1500" placeholder="${esc(w.topicHint)}"></textarea></label><output id="meeting-preview" class="meeting-preview" aria-live="polite">${esc(w.ready)}</output><div class="meeting-action-row"><button type="submit" data-meeting-action="calendar">${esc(w.calendar)}</button><button type="submit" data-meeting-action="email">${esc(w.mail)}</button><button type="submit" data-meeting-action="copy">${esc(w.copy)}</button></div><div class="meeting-status" id="meeting-status" role="status" aria-live="polite"></div></form></div>`;
  updateHost();dialog.showModal();dialog.querySelector('[data-close-meeting]').focus({preventScroll:true});
  const form=dialog.querySelector('form'),p=parts(new Date(),zoneList.local);form.elements.date.min=`${p.year}-${p.month}-${p.day}`;
  form.addEventListener('input',preview);form.addEventListener('change',e=>{if(e.target.name==='category'){updateHost();dialog.querySelector('#meeting-status').textContent='';}preview();});form.addEventListener('submit',submit);
 }
 function getData(){const form=dialog.querySelector('form'),f=form.elements;const start=zonedTime(f.date.value,f.time.value,f.zone.value);return {category:f.category.value,host:hostFor(f.category.value),name:f.name.value.trim(),email:f.email.value.trim(),zone:f.zone.value,topic:f.topic.value.trim(),start,end:start instanceof Date?new Date(+start+30*60000):null};}
 function format(date,zone){return new Intl.DateTimeFormat(lang()==='ko'?'ko-KR':'en-GB',{timeZone:zone,year:'numeric',month:'short',day:'numeric',weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23',timeZoneName:'short'}).format(date);}
 function preview(){const d=getData(),w=labels(),out=dialog.querySelector('#meeting-preview');if(!(d.start instanceof Date)){out.textContent=d.start==='dst'?w.dst:w.ready;return;}out.textContent=`${w.preview}: ${format(d.start,d.zone)} — ${new Intl.DateTimeFormat('en-GB',{timeZone:d.zone,hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(d.end)} · ${d.zone}`;}
 function message(d){const w=labels(),ko=lang()==='ko',name=hostName(d.host);
  const intro=ko?`안녕하세요, ${name} 님. 아래 시간으로 30분 온라인 미팅을 제안드립니다.`:`Hello ${name}, I would like to propose a 30-minute online meeting at the time below.`;
  return `${intro}\n\n${ko?'미팅 담당':'Meeting with'}: ${name} <${d.host.email}>\n${ko?'대화 주제':'Conversation topic'}: ${category(d.category)[lang()]}\n${w.name}: ${d.name}\n${w.email}: ${d.email}\n${w.preview}: ${format(d.start,d.zone)} — ${format(d.end,d.zone)}\n${w.zone}: ${d.zone}\n${w.utc}: ${d.start.toISOString()} / ${d.end.toISOString()}\n${d.topic?'\n'+w.topic+':\n'+d.topic+'\n':''}\n${w.ending}\n\n${w.notice}`;
 }
 function calendarUrl(d){
  const stamp=x=>x.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
  const q=new URLSearchParams({action:'TEMPLATE',text:labels().proposal+' · '+category(d.category)[lang()],dates:stamp(d.start)+'/'+stamp(d.end),ctz:d.zone,details:message(d),add:d.host.email,location:lang()==='ko'?'Google Meet · 일정 확인 후 링크 안내':'Google Meet · link to follow after confirmation'});
  return 'https://calendar.google.com/calendar/render?'+q.toString();
 }
 function emailUrl(d){return 'mailto:'+encodeURIComponent(d.host.email)+'?subject='+encodeURIComponent(labels().proposal+' · '+category(d.category)[lang()])+'&body='+encodeURIComponent(message(d));}

 function status(s,error=false){const e=dialog.querySelector('#meeting-status');e.textContent=s;e.classList.toggle('is-error',error);}
 async function submit(e){
  e.preventDefault();const d=getData(),w=labels();if(!d.name||!d.email){status(w.required,true);return;}
  if(!(d.start instanceof Date)){status(d.start==='dst'?w.dst:w.invalid,true);return;}if(+d.start<Date.now()){status(w.past,true);return;}
  const method=e.submitter?.dataset.meetingAction||'calendar',body=message(d);
  if(method==='copy'){try{await navigator.clipboard.writeText(body);status(w.copied);}catch(_){const ta=document.createElement('textarea');ta.value=body;ta.style.cssText='position:fixed;opacity:0';dialog.append(ta);ta.select();let ok=false;try{ok=document.execCommand('copy');}catch(_){}ta.remove();status(ok?w.copied:w.failed,!ok);}return;}
  if(method==='email'){
   const url=emailUrl(d);location.href=url;status(w.draft);return;
  }
  window.open(calendarUrl(d),'_blank','noopener,noreferrer');status(w.draft);
 }
 document.addEventListener('click',e=>{const b=e.target.closest('[data-open-meeting]');if(b){e.preventDefault();open(b);}});
 dialog.addEventListener('click',e=>{if(e.target.closest('[data-close-meeting]'))dialog.close();else if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
 dialog.addEventListener('close',()=>{document.body.style.overflow=overflow;if(back?.isConnected)back.focus({preventScroll:true});dialog.innerHTML='';back=null;});
 document.addEventListener('civic:route',()=>{if(dialog.open)dialog.close();});
 // Deterministic routing and URL builders for offline tests. No authentication or calendar data.
 window.CivicMeeting={zonedTime,bookingUrl,hostFor,calendarUrl,emailUrl};
})();

;
/* Civic Ledger v6 — interaction layer, independent of article copy.
 * Private highlights are never sent to the optional discussion server.
 * Static-file mode: reactions and comments are explicitly browser-local.
 * No third-party scripts, trackers, pre-filled reactions or sample comments.
 */
'use strict';
(() => {
 const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const icon=(name)=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${name==='heart'?' class="cl-heart"':''}>${({heart:'<path d="M20.4 4.6a5.4 5.4 0 0 0-7.6 0l-.8.8-.8-.8a5.4 5.4 0 0 0-7.6 7.6L12 21l8.4-8.8a5.4 5.4 0 0 0 0-7.6Z"/>',comment:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5H4l-2 2V11.5a9.5 9.5 0 0 1 19 0Z"/><path d="M7 9h9M7 13h6"/>',pen:'<path d="m15 3 6 6-9 9-7 1 1-7Z"/><path d="m13 5 6 6M3 22h18"/>',share:'<path d="M12 16V2m-5 5 5-5 5 5M5 12v9h14v-9"/>',copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',close:'<path d="m6 6 12 12M18 6 6 18"/>',zoom:'<circle cx="10" cy="10" r="6.5"/><path d="m15 15 6 6M10 7v6m-3-3h6"/>',arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>',lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4"/>',mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',check:'<path d="m5 12 4 4 10-10"/>'})[name]||''}</svg>`;
 const words={
 ko:{like:'좋아요',liked:'좋아요 취소',comment:'댓글',share:'공유',highlights:'하이라이트',myHighlights:'내 하이라이트',dialogue:'대화',hint:'기억하고 싶은 문장을 선택해 보세요.',discussion:'읽은 뒤, 이어지는 생각',discussionSub:'인상 깊은 문장, 남은 질문, 다른 관점을 남겨주세요.',local:'브라우저 미리보기',localNote:'댓글과 좋아요는 이 브라우저에만 저장됩니다. 다른 방문자에게는 공개되지 않습니다.',volatile:'저장이 제한된 환경입니다. 이 탭을 닫으면 기록이 사라질 수 있습니다.',shared:'공동 테스트 모드',sharedNote:'이 서버에 접속한 사람들과 댓글·좋아요를 함께 봅니다. 하이라이트와 메모는 내 브라우저에만 남습니다.',sideTitle:'함께 읽는 방법',side:'문장을 선택하면 하이라이트하거나 그 문장을 인용해 댓글을 남길 수 있습니다. 의견의 차이는 환영합니다. 개인 정보는 적지 말아 주세요.',name:'표시할 이름',namePlaceholder:'이름 또는 별명',commentLabel:'생각 남기기',commentPlaceholder:'어떤 부분에 공감했나요? 무엇을 더 이야기해 보고 싶나요?',postLocal:'댓글 저장',postShared:'댓글 게시',editSave:'수정 저장',cancel:'취소',quote:'인용한 문장',removeQuote:'인용 빼기',replying:'답글 작성 중',reply:'답글',edit:'수정',delete:'삭제',mine:'내 댓글',emptyTitle:'아직 남겨진 댓글이 없습니다.',emptyBody:'본문의 문장을 선택해 이야기의 출발점으로 삼아도 좋습니다.',saved:'저장했습니다.',posted:'댓글을 저장했습니다.',publicPosted:'댓글을 게시했습니다.',deleted:'삭제했습니다.',confirmDelete:'이 기록을 삭제할까요?',select:'문장 하이라이트',quoteComment:'인용 댓글',quoteShare:'문장 공유',markSaved:'하이라이트를 저장했습니다.',markExisting:'이미 저장한 하이라이트입니다.',tooLong:'한 번에 3,000자 이내로 선택해 주세요.',noSelection:'본문에서 기억하고 싶은 문장을 선택해 주세요.',noHighlights:'아직 저장한 하이라이트가 없습니다.',highlightHelp:'본문을 드래그해 문장을 선택한 뒤 ‘하이라이트’를 누르세요. 휴대폰에서는 문장을 길게 눌러 선택할 수 있습니다.',private:'나만 보는 기록 · 현재 언어의 글',privateMemo:'개인 메모',memoPlaceholder:'이 문장을 남긴 이유는 무엇인가요?',autoSave:'메모는 이 브라우저에 자동 저장됩니다.',goQuote:'본문의 이 문장으로 이동',export:'기록 내보내기',copied:'복사했습니다.',copyFail:'자동 복사가 지원되지 않습니다. 아래 내용을 직접 복사해 주세요.',copyLink:'링크 복사',copyText:'공유 문구 복사',shareHeading:'이 글을 나누기',native:'다른 앱',mail:'이메일',localShare:'지금은 내 컴퓨터의 미리보기입니다. 공개 주소가 없어 글의 제목과 선택 문장만 공유됩니다. 로컬 파일 경로는 전송하지 않습니다.',publicUrl:'공유용 공개 주소 설정',publicLabel:'실제로 배포한 저널 페이지의 HTTPS 주소',publicPlaceholder:'https://your-site.example/journal/',publicSave:'이 브라우저에 저장',publicHint:'공개 배포 후에만 설정해 주세요. 현재 파일을 업로드하거나 공개하는 기능은 아닙니다.',invalidUrl:'localhost가 아닌 실제 HTTPS 주소를 입력해 주세요.',linked:'공개 주소를 저장했습니다.',clearUrl:'공개 주소 지우기',urlMissing:'링크 공유는 공개 주소를 연결한 뒤 사용할 수 있습니다.',manualCopy:'직접 복사',emptyName:'표시할 이름을 입력해 주세요.',emptyComment:'댓글 내용을 입력해 주세요.',quoteActions:'선택한 문장',yellow:'노란색',sage:'연두색',rose:'분홍색',storageError:'저장 공간에 기록하지 못했습니다. 기록 내보내기로 사본을 보관하세요.',chooseQuote:'이 문장에 대한 생각을 적어 주세요.',deletedComment:'삭제된 댓글입니다.',readNotes:'나의 읽기 기록',consent:'이 댓글을 이 서버의 다른 방문자에게 공개합니다.',needConsent:'게시 전에 공개 범위를 확인해 주세요.',serverError:'서버에 저장하지 못했습니다. 입력 내용은 그대로 남아 있습니다.',serverUnavailable:'댓글 서버에 연결하지 못했습니다. 잠시 후 다시 시도해 주세요.',zoom:'크게 보기',privateNotes:'메모와 하이라이트는 공유되지 않습니다.',shareQuotedHint:'LinkedIn·네이버·Facebook은 링크를 공유합니다. 선택 문장은 ‘공유 문구 복사’로 함께 붙여 넣으세요.',quoteRead:'선택 문장을 본문에서 확인'},
 en:{like:'Like',liked:'Unlike',comment:'Comments',share:'Share',highlights:'Highlights',myHighlights:'My highlights',dialogue:'Conversation',hint:'Select a passage you want to keep.',discussion:'The conversation continues',discussionSub:'Leave a passage, a question or another perspective.',local:'Browser preview',localNote:'Comments and likes are saved in this browser only. Other visitors cannot see them.',volatile:'Storage is restricted. Your notes may be lost when this tab closes.',shared:'Shared test mode',sharedNote:'Comments and likes are shared with people using this server. Highlights and private notes stay in your browser.',sideTitle:'Reading together',side:'Select a passage to highlight it or quote it in a comment. Different perspectives are welcome. Please do not include personal information.',name:'Display name',namePlaceholder:'Your name or nickname',commentLabel:'Leave a thought',commentPlaceholder:'What resonated? What would you like to explore further?',postLocal:'Save comment',postShared:'Post comment',editSave:'Save changes',cancel:'Cancel',quote:'Quoted passage',removeQuote:'Remove quote',replying:'Replying',reply:'Reply',edit:'Edit',delete:'Delete',mine:'Your comment',emptyTitle:'No comments yet.',emptyBody:'You can select a passage from the essay as a starting point.',saved:'Saved.',posted:'Comment saved in this browser.',publicPosted:'Comment posted.',deleted:'Deleted.',confirmDelete:'Delete this record?',select:'Highlight',quoteComment:'Comment',quoteShare:'Share passage',markSaved:'Highlight saved.',markExisting:'This passage is already saved.',tooLong:'Please select up to 3,000 characters at a time.',noSelection:'Select a passage in the article first.',noHighlights:'No highlights saved yet.',highlightHelp:'Select text in the article, then choose Highlight. On a phone, touch and hold a passage to select it.',private:'Private notes · this language edition',privateMemo:'Private note',memoPlaceholder:'Why did you keep this passage?',autoSave:'Notes are saved automatically in this browser.',goQuote:'Go to this passage in the article',export:'Export notes',copied:'Copied.',copyFail:'Automatic copying is unavailable. Please copy the text below.',copyLink:'Copy link',copyText:'Copy share text',shareHeading:'Share this essay',native:'More apps',mail:'Email',localShare:'This is a local preview, without a public article URL. Only the title and selected passage are shared. Your local file path is never sent.',publicUrl:'Set a published URL',publicLabel:'HTTPS address of your deployed journal page',publicPlaceholder:'https://your-site.example/journal/',publicSave:'Save in this browser',publicHint:'Set this only after deployment. This does not upload or publish the local file.',invalidUrl:'Enter a public HTTPS URL, not localhost.',linked:'Published URL saved.',clearUrl:'Remove published URL',urlMissing:'Link sharing needs a published article URL.',manualCopy:'Copy manually',emptyName:'Please enter a display name.',emptyComment:'Please write a comment.',quoteActions:'Selected passage',yellow:'Yellow',sage:'Sage',rose:'Rose',storageError:'Could not persist this change. Export a copy of your notes.',chooseQuote:'Write your thoughts about this passage.',deletedComment:'This comment was deleted.',readNotes:'My reading notes',consent:'Share this comment with other visitors to this server.',needConsent:'Please confirm the audience before posting.',serverError:'Could not save to the server. Your draft is still here.',serverUnavailable:'The comment server is unavailable. Please try again shortly.',zoom:'View larger',privateNotes:'Highlights and private notes are not shared.',shareQuotedHint:'LinkedIn and Facebook share the link. Use Copy share text to paste the selected passage alongside it.',quoteRead:'Find selected passage in the article'}
 };
 const STORE='civic-ledger-reader-v5';
 let db={version:1,articles:{},highlights:{},drafts:{},name:'',publicBaseUrl:''},persist=true;
 try{localStorage.setItem(STORE+'-test','1');localStorage.removeItem(STORE+'-test');const raw=JSON.parse(localStorage.getItem(STORE)||'null');if(raw&&raw.version===1)db={...db,...raw};}catch(_){persist=false;}
 let current=null, blockElements=[],selection=null,quoted=null,replyTo=null,editing=null,tab='comments',shareQuote='',shareAnchor=null,shareFocus=null,timer=null;
 let mountSerial=0, live=false,liveState=null,session=null,io=null;
 const config=window.CIVIC_READER_CONFIG||{};
 const ko=()=>document.documentElement.lang.startsWith('ko');const T=()=>words[ko()?'ko':'en'];
 const articleKey=()=>current?`${current.id}-${current.lang}`:'';
 const article=()=>{if(!current)return {liked:false,comments:[]};return db.articles[current.id]||(db.articles[current.id]={liked:false,comments:[]});};
 const highs=()=>db.highlights[articleKey()]||(db.highlights[articleKey()]=[]);
 const uid=()=>globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
 function toast(text){const e=$('#toast');e.textContent=text;e.hidden=false;clearTimeout(timer);timer=setTimeout(()=>e.hidden=true,4000);}
 function save(){try{if(persist)localStorage.setItem(STORE,JSON.stringify(db));}catch(_){persist=false;toast(T().storageError);}}
 const date=s=>{try{return new Intl.DateTimeFormat(ko()?'ko-KR':'en-GB',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date(s));}catch(_){return '';}};
 const comments=()=>live?(liveState?.comments||[]):article().comments;
 const liked=()=>live?!!liveState?.liked:!!article().liked;
 const countLike=()=>live?(liveState?.likes||0):(article().liked?1:0);
 function aButton(action,label,ic,extra=''){return `<button type="button" class="cl-action" data-cl-action="${action}" ${extra}>${icon(ic)}<span>${esc(label)}</span></button>`;}
 function actionMarkup(dock=false){return `${aButton('like',T().like,'heart',`aria-pressed="${liked()}" title="${esc(liked()?T().liked:T().like)}"`)}${aButton('comments',T().comment,'comment')}${aButton('highlights',dock?T().highlights:T().myHighlights,'pen')}${aButton('share',T().share,'share')}`;}
 function refreshCounts(){
  $$('#article-panel [data-cl-action="like"]').forEach(b=>{b.classList.toggle('is-liked',liked());b.setAttribute('aria-pressed',String(liked()));b.title=liked()?T().liked:T().like;b.innerHTML=icon('heart')+`<span>${esc(T().like)}</span>${live?`<span class="cl-mini-count">${countLike()}</span>`:''}`;});
  $$('#article-panel [data-cl-action="comments"]').forEach(b=>b.innerHTML=icon('comment')+`<span>${esc(T().comment)}</span><span class="cl-mini-count">${comments().filter(c=>!c.deleted).length}</span>`);
  $$('#article-panel [data-cl-action="highlights"]').forEach(b=>b.innerHTML=icon('pen')+`<span>${esc(b.closest('.cl-dock')?T().highlights:T().myHighlights)}</span><span class="cl-mini-count">${highs().length}</span>`);
  $('#cl-comment-count')&&( $('#cl-comment-count').textContent=comments().filter(c=>!c.deleted).length );
  $('#cl-highlight-count')&&( $('#cl-highlight-count').textContent=highs().length );
 }
 function mount(){
  mountSerial++;const serial=mountSerial;
  if($('#cl-share')?.open)$('#cl-share').close();
  const queryArticle=new URLSearchParams(location.search).get('article');
  const match=location.hash.match(/^#article\/([a-z0-9]+)/)||(!location.hash&&queryArticle?['',queryArticle]:null)||(!location.hash&&window.CivicJournal?.currentArticle?['',window.CivicJournal.currentArticle]:null);
  selection=null;hideSelection();quoted=null;replyTo=null;editing=null;liveState=null;
  io?.disconnect();io=null;$$('.cl-actionbar,.cl-discussion,.cl-dock').forEach(e=>e.remove());
  if(!match||$('#article-panel').hidden){current=null;return;}
  current={id:match[1],lang:ko()?'ko':'en'};live=!!config.apiBase;
  const data=window.CivicJournal.data.articles[articleKey()];if(!data||data.status==='forthcoming'){current=null;return;}current.title=data.title;
  const root=$('#article-content');
  blockElements=[...root.querySelectorAll('.body-copy > p:not(.source-warning),.source-prose > p,.source-prose .source-list > li,.body-copy table td')];
  blockElements.forEach((p,i)=>{p.dataset.clBlock=p.dataset.sourceParagraph?'final-'+current.id+'-'+current.lang+'-'+p.dataset.sourceParagraph:'p'+i;if(!p.id)p.id='cl-'+current.id+'-'+current.lang+'-p'+i;});
  root.querySelectorAll('.source-prose figure > button,.reading-one .final-figure > button').forEach(b=>{if(b.closest('.inline-figure'))return;if(!b.querySelector('.reader-image-hint'))b.insertAdjacentHTML('beforeend',`<span class="reader-image-hint" aria-hidden="true">${icon('zoom')}${esc(T().zoom)}</span>`);});
  const bar=document.createElement('div');bar.className='cl-reader cl-actionbar';bar.setAttribute('aria-label',ko()?'글 반응과 공유':'Article actions');bar.innerHTML=actionMarkup()+`<span class="cl-bar-hint">${esc(T().hint)}</span>`;
  const header=root.querySelector('.hero')||root.querySelector('.source-title');header?.after(bar);
  const tail=$('#article-tail');
  tail.insertAdjacentHTML('afterbegin',`<section class="cl-reader cl-discussion" id="cl-discussion" aria-labelledby="cl-discussion-title"><header class="cl-discussion-head"><div><div class="cl-overline">Civic Ledger · ${esc(T().readNotes)}</div><h2 id="cl-discussion-title">${esc(T().discussion)}</h2><p>${esc(T().discussionSub)}</p></div>${live?`<button type="button" class="cl-text-btn" data-cl-action="refresh-comments">${ko()?'댓글 새로고침':'Refresh comments'} ↻</button>`:''}</header><div class="cl-tabs" role="tablist" aria-label="${esc(T().readNotes)}"><button type="button" id="cl-comments-tab" role="tab" data-cl-tab="comments" aria-controls="cl-comments-panel" aria-selected="true">${esc(T().dialogue)} <span id="cl-comment-count" class="cl-mini-count">0</span></button><button type="button" id="cl-highlights-tab" role="tab" data-cl-tab="highlights" aria-controls="cl-highlights-panel" aria-selected="false" tabindex="-1">${esc(T().myHighlights)} <span id="cl-highlight-count" class="cl-mini-count">0</span></button></div><div id="cl-comments-panel" role="tabpanel" aria-labelledby="cl-comments-tab"><div class="cl-discussion-layout"><div><form class="cl-compose" id="cl-comment-form"><div id="cl-compose-context"></div><label for="cl-name">${esc(T().name)}</label><input id="cl-name" name="displayName" maxlength="50" placeholder="${esc(T().namePlaceholder)}" value="${esc(db.name)}" required autocomplete="nickname"><label for="cl-comment-body">${esc(T().commentLabel)}</label><textarea id="cl-comment-body" maxlength="2000" placeholder="${esc(T().commentPlaceholder)}" required>${esc(db.drafts[current.id]||'')}</textarea>${live?`<label class="cl-live-consent"><input type="checkbox" id="cl-consent" required>${esc(T().consent)}</label>`:''}<div class="cl-compose-footer"><span id="cl-charcount" class="cl-charcount">0 / 2,000</span><div><button type="button" class="cl-text-btn" data-cl-action="cancel-compose" hidden>${esc(T().cancel)}</button><button type="submit" class="cl-submit" id="cl-post">${esc(live?T().postShared:T().postLocal)}</button></div></div><p class="cl-storage-note" id="cl-storage-note">${esc(!persist?T().volatile:live?T().sharedNote:T().localNote)}</p></form><div id="cl-comments-list" aria-live="polite"></div></div><aside class="cl-aside"><strong>${icon('comment')} ${esc(T().sideTitle)}</strong>${esc(T().side)}<p>${icon('lock')} ${esc(T().privateNotes)}</p></aside></div></div><div id="cl-highlights-panel" role="tabpanel" aria-labelledby="cl-highlights-tab" hidden><div class="cl-highlights-toolbar"><p>${icon('lock')} ${esc(T().private)}</p><button type="button" class="cl-text-btn" data-cl-action="export">${esc(T().export)} ↓</button></div><div id="cl-highlight-list"></div></div></section>`);
  const dock=document.createElement('div');dock.className='cl-reader cl-dock';dock.hidden=true;dock.setAttribute('aria-label',ko()?'읽기 도구':'Reading tools');dock.innerHTML=`<span class="cl-dock-title">${ko()?'읽기 도구':'Reading tools'}</span>`+actionMarkup(true);$('#article-panel').append(dock);
  tab='comments';renderComments();renderHighlights();applyHighlights();refreshCounts();updateCharCount();
  $('#cl-comment-form').addEventListener('submit',postComment);
  $('#cl-comment-body').addEventListener('input',()=>{updateCharCount();if(!editing){db.drafts[current.id]=$('#cl-comment-body').value;save();}});
  $('#cl-name').addEventListener('input',()=>{db.name=$('#cl-name').value;save();});
  if(live){$('#cl-post').disabled=true;getShared(serial);}
  const params=new URLSearchParams((location.hash.split('?')[1]||''));const block=params.get('p'),quote=params.get('quote');
  if(block||quote)requestAnimationFrame(()=>{if(serial!==mountSerial)return;const found=quote?blockElements.find(e=>e.textContent.includes(quote)):blockElements.find(e=>e.dataset.clBlock===block);if(found){found.scrollIntoView({block:'center',behavior:'instant'});toast(T().quoteRead);}});
  requestAnimationFrame(updateDock);
 }
 function updateCharCount(){const el=$('#cl-comment-body');if(el)$('#cl-charcount').textContent=el.value.length.toLocaleString()+' / 2,000';}
 function setTab(next,scroll=true){if(!current)return;tab=next;$$('[data-cl-tab]').forEach(b=>{const on=b.dataset.clTab===next;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;});$('#cl-comments-panel').hidden=next!=='comments';$('#cl-highlights-panel').hidden=next!=='highlights';if(next==='highlights')renderHighlights();if(scroll)$('#cl-discussion').scrollIntoView({block:'start',behavior:'instant'});}
 function reduced(){return matchMedia('(prefers-reduced-motion: reduce)').matches;}
 function updateDock(){const dock=$('.cl-dock');if(!current||!dock)return;const bar=$('.cl-actionbar'),area=$('#cl-discussion');if(!bar||!area)return;dock.hidden=bar.getBoundingClientRect().bottom>100||area.getBoundingClientRect().top<innerHeight*.82||!!$('dialog[open]');}
 window.addEventListener('scroll',updateDock,{passive:true});window.addEventListener('resize',()=>{hideSelection();updateDock();});
 function renderComments(){
  const list=$('#cl-comments-list');if(!list||!current)return;
  const all=comments();
  function row(c,isReply=false){const own=live?c.own:true;return `<article class="cl-comment ${isReply?'cl-reply':''}" data-comment-id="${esc(c.id)}"><div class="cl-comment-head"><span class="cl-avatar" aria-hidden="true">${esc((c.name||'?').slice(0,1))}</span><div><strong>${esc(c.name||'—')}</strong><time datetime="${esc(c.created)}">${esc(date(c.created))}${own?' · '+esc(T().mine):''}</time></div></div>${c.quote&&!c.deleted?`<blockquote lang="${esc(c.quoteLang||current.lang)}">${esc(c.quote)}</blockquote>`:''}<p class="cl-comment-body">${esc(c.deleted?T().deletedComment:c.body)}</p>${!c.deleted?`<div><button type="button" class="cl-text-btn" data-cl-reply="${esc(isReply?c.parent:c.id)}">${esc(T().reply)}</button>${own?`<button type="button" class="cl-text-btn" data-cl-edit="${esc(c.id)}">${esc(T().edit)}</button><button type="button" class="cl-text-btn" data-cl-delete="${esc(c.id)}">${esc(T().delete)}</button>`:''}</div>`:''}${!isReply?all.filter(r=>r.parent===c.id).map(r=>row(r,true)).join(''):''}</article>`;}
  list.innerHTML=all.length?all.filter(c=>!c.parent).map(c=>row(c)).join(''):`<div class="cl-empty"><h3>${esc(T().emptyTitle)}</h3><p>${esc(T().emptyBody)}</p></div>`;
  refreshCounts();
 }
 function composeContext(){
  const host=$('#cl-compose-context');if(!host)return;
  host.innerHTML=(replyTo?`<div class="cl-quote-context">${esc(T().replying)} · ${esc(comments().find(c=>c.id===replyTo)?.name||'')}</div>`:'')+(quoted?`<div class="cl-quote-context"><strong>${esc(T().quote)}</strong><blockquote>${esc(quoted.text)}</blockquote><button type="button" class="cl-text-btn" data-cl-action="remove-quote">${esc(T().removeQuote)}</button></div>`:'');
  $('[data-cl-action="cancel-compose"]').hidden=!editing&&!quoted&&!replyTo;
  $('#cl-post').textContent=editing?T().editSave:(live?T().postShared:T().postLocal);
 }
 function cancelCompose(){editing=null;quoted=null;replyTo=null;$('#cl-comment-body').value=db.drafts[current.id]||'';composeContext();updateCharCount();}
 async function postComment(e){
  e.preventDefault();if(!current)return;const id=current.id, serial=mountSerial;
  const name=$('#cl-name').value.trim(),body=$('#cl-comment-body').value.trim();
  if(!name){toast(T().emptyName);$('#cl-name').focus();return;}if(!body){toast(T().emptyComment);$('#cl-comment-body').focus();return;}
  if(live&&!$('#cl-consent').checked){toast(T().needConsent);return;}
  const values={...(live?{consent:true}:{}),name:name.slice(0,50),body:body.slice(0,2000),quote:quoted?.text||'',quoteLang:quoted?.lang||current.lang,parent:replyTo||null};
  $('#cl-post').disabled=true;
  try{
   if(live){if(!session)throw Error('No session');await api(`/articles/${id}/comments${editing?'/'+encodeURIComponent(editing):''}`,editing?'PATCH':'POST',values);await getShared(serial);}
   else if(editing){const c=article().comments.find(c=>c.id===editing);if(c)Object.assign(c,values,{updated:new Date().toISOString()});}
   else{article().comments.push({...values,id:uid(),created:new Date().toISOString()});}
   db.name=name;delete db.drafts[id];save();
   if(serial!==mountSerial)return;quoted=null;replyTo=null;editing=null;$('#cl-comment-body').value='';if($('#cl-consent'))$('#cl-consent').checked=false;composeContext();updateCharCount();renderComments();toast(live?T().publicPosted:T().posted);
  }catch(_){toast(T().serverError);}finally{if(serial===mountSerial)$('#cl-post').disabled=live&&!session;}
 }
 async function toggleLike(){if(!current)return;const serial=mountSerial;if(live){if(!session){toast(T().serverUnavailable);return;}try{await api(`/articles/${current.id}/like`,'PUT',{liked:!liked()});await getShared(serial);}catch(_){toast(T().serverError);}}else{article().liked=!article().liked;save();refreshCounts();}}
 async function deleteComment(id){if(!confirm(T().confirmDelete))return;if(live){try{await api(`/articles/${current.id}/comments/${encodeURIComponent(id)}`,'DELETE');await getShared(mountSerial);}catch(_){toast(T().serverError);}}else{const a=article(),c=a.comments.find(c=>c.id===id);if(a.comments.some(r=>r.parent===id)){if(c){c.deleted=true;c.body='';c.quote='';}}else a.comments=a.comments.filter(c=>c.id!==id);save();renderComments();}if(editing===id)cancelCompose();}
 function prepareBlocks(){blockElements.forEach(el=>{el.querySelectorAll('mark.cl-highlight').forEach(m=>m.replaceWith(...m.childNodes));el.normalize();});}
 function applyHighlights(){
  if(!current)return;prepareBlocks();
  blockElements.forEach(el=>{
   const segments=highs().flatMap(h=>(h.segments||[]).filter(s=>s.block===el.dataset.clBlock).map(s=>({...s,id:h.id,colour:h.colour||'yellow'}))).filter(s=>el.textContent.slice(s.start,s.end)===s.text);
   if(!segments.length)return;
   const walk=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);const nodes=[];let n,offset=0;
   while(n=walk.nextNode()){nodes.push({node:n,start:offset,end:offset+n.length});offset+=n.length;}
   nodes.forEach(({node,start,end})=>{
    const ints=segments.filter(s=>s.end>start&&s.start<end);if(!ints.length)return;
    const cuts=[...new Set([start,end,...ints.flatMap(s=>[Math.max(start,s.start),Math.min(end,s.end)])])].sort((a,b)=>a-b),frag=document.createDocumentFragment();
    for(let i=0;i<cuts.length-1;i++){const a=cuts[i],b=cuts[i+1],slice=node.data.slice(a-start,b-start);const hit=ints.filter(s=>s.start<=a&&s.end>=b).at(-1);if(hit){const mark=document.createElement('mark');mark.className='cl-highlight';mark.dataset.clHighlight=hit.id;mark.dataset.colour=hit.colour;mark.title=T().privateMemo;mark.textContent=slice;frag.append(mark);}else frag.append(document.createTextNode(slice));}
    node.replaceWith(frag);
   });
  });
 }
 function captureSelection(){
  if(!current||$('dialog[open]')||$('.cl-reader input:focus,.cl-reader textarea:focus'))return;
  const sel=window.getSelection();if(!sel||sel.isCollapsed||!sel.rangeCount){hideSelection();return;}
  const r=sel.getRangeAt(0);const start=blockElements.find(el=>el.contains(r.startContainer)),end=blockElements.find(el=>el.contains(r.endContainer));
  if(!start||!end){hideSelection();return;}
  const segments=[];
  for(const el of blockElements){if(!r.intersectsNode(el))continue;let a=0,b=el.textContent.length;
   if(el.contains(r.startContainer)){const p=document.createRange();p.selectNodeContents(el);p.setEnd(r.startContainer,r.startOffset);a=p.toString().length;}
   if(el.contains(r.endContainer)){const p=document.createRange();p.selectNodeContents(el);p.setEnd(r.endContainer,r.endOffset);b=p.toString().length;}
   const text=el.textContent.slice(a,b);if(text.trim())segments.push({block:el.dataset.clBlock,start:a,end:b,text});
  }
  const text=segments.map(s=>s.text).join('\n\n');if(text.trim().length<2){hideSelection();return;}
  selection={text,segments,lang:current.lang};showSelection(r);
 }
 function showSelection(range){
  const bar=$('#cl-selection');bar.setAttribute('aria-label',T().quoteActions);
  bar.innerHTML=`<button type="button" data-cl-selection="highlight">${icon('pen')}${esc(ko()?'하이라이트':'Highlight')}</button><button type="button" data-cl-selection="comment">${icon('comment')}${esc(T().quoteComment)}</button><button type="button" data-cl-selection="share">${icon('share')}${esc(ko()?'공유':'Share')}</button><button type="button" data-cl-selection="close" aria-label="${esc(T().cancel)}">${icon('close')}</button>`;
  bar.hidden=false;
  const safeTop=(document.querySelector('.site-header')?.getBoundingClientRect().height||0)+(document.querySelector('.reader-bar')?.getBoundingClientRect().height||0)+8;
  const rects=[...range.getClientRects()].filter(r=>r.width>1&&r.height>1);const r=rects.find(r=>r.top>safeTop)||rects[0]||range.getBoundingClientRect();
  const w=bar.offsetWidth,h=bar.offsetHeight;let top=r.top-h-10;if(top<safeTop)top=Math.min(innerHeight-h-16,r.bottom+12);bar.style.left=Math.max(10,Math.min(innerWidth-w-10,r.left+r.width/2-w/2))+'px';bar.style.top=Math.max(12,top)+'px';
 }
 function hideSelection(){const b=$('#cl-selection');if(b)b.hidden=true;}
 function saveHighlight(sel){
  if(!sel||!current)return;if(sel.text.length>3000){toast(T().tooLong);return;}
  const old=highs().find(h=>JSON.stringify(h.segments)===JSON.stringify(sel.segments));if(old){toast(T().markExisting);return old;}
  const h={...sel,id:uid(),colour:'yellow',memo:'',created:new Date().toISOString()};highs().push(h);save();window.getSelection()?.removeAllRanges();hideSelection();applyHighlights();refreshCounts();renderHighlights();toast(persist?T().markSaved:T().volatile);return h;
 }
 function renderHighlights(){
  const host=$('#cl-highlight-list');if(!host||!current)return;
  host.innerHTML=!highs().length?`<div class="cl-empty"><h3>${esc(T().noHighlights)}</h3><p>${esc(T().highlightHelp)}</p></div>`:highs().map(h=>`<article class="cl-highlight-entry" data-highlight-entry="${esc(h.id)}"><button type="button" class="cl-quote-jump" data-cl-jump="${esc(h.id)}" title="${esc(T().goQuote)}">${esc(h.text)}</button><div class="cl-hl-actions"><span class="cl-sr">${ko()?'색상':'Colour'}</span>${['yellow','sage','rose'].map(c=>`<button type="button" class="cl-colour" data-colour="${c}" data-cl-colour="${esc(h.id)}" aria-label="${esc(T()[c])}" aria-pressed="${h.colour===c}">${h.colour===c?'✓':''}</button>`).join('')}<button type="button" class="cl-text-btn" data-cl-hl-comment="${esc(h.id)}">${esc(T().quoteComment)}</button><button type="button" class="cl-text-btn" data-cl-hl-share="${esc(h.id)}">${esc(T().share)}</button><button type="button" class="cl-text-btn" data-cl-hl-delete="${esc(h.id)}">${esc(T().delete)}</button></div><label class="cl-memo-label" for="memo-${esc(h.id)}">${icon('lock')} ${esc(T().privateMemo)}</label><textarea id="memo-${esc(h.id)}" class="cl-private-memo" data-cl-memo="${esc(h.id)}" maxlength="1500" rows="2" placeholder="${esc(T().memoPlaceholder)}">${esc(h.memo||'')}</textarea></article>`).join('');refreshCounts();
 }
 function quoteInComment(value){quoted={text:value.text.slice(0,3000),lang:value.lang||current.lang};editing=null;replyTo=null;hideSelection();window.getSelection()?.removeAllRanges();setTab('comments');composeContext();setTimeout(()=>$('#cl-comment-body')?.focus({preventScroll:true}),350);}
 function jumpHighlight(id){const h=highs().find(h=>h.id===id);if(!h)return;const el=blockElements.find(e=>e.dataset.clBlock===h.segments[0]?.block);if(el){el.scrollIntoView({block:'center',behavior:reduced()?'instant':'smooth'});el.querySelectorAll('mark').forEach(m=>{m.classList.add('cl-flash');setTimeout(()=>m.classList.remove('cl-flash'),1400);});}}
 function exportNotes(){const data=Object.entries(db.highlights).filter(([,v])=>v.length);if(!data.length){toast(T().noHighlights);return;}let out='# Civic Ledger — Private reading notes\n\n';for(const [key,items] of data){const title=window.CivicJournal.data.articles[key]?.title||key;out+=`## ${title} (${key})\n\n`;for(const h of items)out+=h.text.split('\n').map(x=>'> '+x).join('\n')+'\n\n'+(h.memo?h.memo+'\n\n':'');}const blob=new Blob([out],{type:'text/markdown;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='Civic_Ledger_Reading_Notes.md';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);}

/* v6 share composer. Uses the supplied article artwork + the index's existing
 * editorial introduction. No AI service, tracker, auto-posting or private notes.
 * This module is inserted inside reader-social.js by build.py. */
 let shareMode='plain', shareThought='', shareCardBlob=null, shareCardFile=null, shareCardURL='', shareRenderSeq=0;
 const SW=()=>ko()?{
  plain:'그대로 공유',thought:'내 생각 덧붙이기',preview:'공유 미리보기',yourThought:'내 생각',placeholder:'이 글을 나누는 이유나 떠오른 질문을 적어보세요.',
  auto:'이미지·제목·글 소개를 자동으로 준비했습니다. 그대로 나누거나 내 생각을 덧붙이세요.',
  quoted:'선택한 문장으로 인용 카드를 준비했습니다. 원문과 내 생각은 구분해서 공유됩니다.',
  send:'이미지·텍스트 공유',save:'이미지 저장',caption:'공유 문구 확인',loading:'공유 이미지 만드는 중…',cardNote:'글의 이미지와 제목이 담긴 카드 · 1,200 × 1,200',quoteNote:'선택 문장이 담긴 인용 카드 · 1,200 × 1,200',
  privacy:'개인 메모는 가져오지 않습니다. 내 생각은 공유 문구에 추가되며 원문 이미지에는 합성하지 않습니다.',
  local:'로컬 미리보기에서는 이미지와 문구를 준비합니다. 링크 미리보기는 공개 배포 후 작동합니다.',
  platform:'LinkedIn·네이버·Facebook은 링크 공유 창을 엽니다. 이미지를 직접 첨부하려면 이미지·텍스트 공유 또는 이미지 저장을 이용하세요.',
  noteSent:'공유 창을 열었습니다. 최종 게시 내용은 선택한 앱에서 확인해 주세요.',
  fallback:'이 브라우저에서는 이미지 파일을 앱으로 바로 전달할 수 없습니다. 이미지를 저장하고 공유 문구를 복사했습니다. 원하는 앱에 이미지와 문구를 함께 붙여 주세요.',
  fallbackManual:'이미지를 저장했습니다. 아래 공유 문구를 직접 복사해 원하는 앱에 함께 붙여 주세요.',
  failed:'이미지를 준비하지 못했습니다. 문구 복사는 사용할 수 있습니다.',
  clipboardDone:'이미지를 복사했습니다. 지원하는 앱에 붙여 넣으세요.',
  clipboardNo:'이 브라우저에서는 이미지 복사가 지원되지 않습니다. ‘이미지 저장’을 이용하세요.',
  copyImage:'이미지 복사',downloaded:'공유 이미지를 저장했습니다.',
  linkNote:'공유 문구를 복사했습니다. LinkedIn·네이버·Facebook 작성창에서 붙여 넣고 최종 내용을 확인해 주세요.',
  xNote:'X의 작성창에서 글자 수를 확인해 주세요. 내용은 자동으로 줄이지 않았습니다.',
  previewNote:'이 미리보기는 공유할 내용입니다. 각 소셜 앱의 배치는 달라질 수 있습니다.',
  publication:'공개 사이트 주소 연결',rootURL:'실제로 배포한 저널의 HTTPS 주소',
  credit:'박아영 · 강은지',selected:'본문에서 고른 문장',excerpt:'글 소개',withLink:'공유 링크',noLink:'공개 주소 연결 전',
  fullQuote:'긴 선택 문장은 이미지에서만 줄여 표시됩니다. 공유 문구에는 전체가 포함됩니다.'
 }:{
  plain:'Share as is',thought:'Add a thought',preview:'Share preview',yourThought:'Your thought',placeholder:'Why share this essay? Add a reflection or a question.',
  auto:'The image, title and introduction are ready. Share them as they are, or add your own thought.',
  quoted:'A quote card is ready for the selected passage. Your thought stays distinct from the original text.',
  send:'Share image & text',save:'Save image',caption:'Review share text',loading:'Preparing share image…',cardNote:'Article image and title · 1,200 × 1,200',quoteNote:'Selected-passage card · 1,200 × 1,200',
  privacy:'Private notes are never imported. Your thought is added to the share text, not printed over the original article image.',
  local:'This local preview prepares an image and text. Link preview cards require public deployment.',
  platform:'LinkedIn, X and Facebook open link-sharing windows. To attach an image, use Share image & text or Save image.',
  noteSent:'Share window opened. Review the final post in the app you choose.',
  fallback:'This browser cannot pass an image file directly to another app. The image has been saved and the share text copied. Attach the image and paste the text in your chosen app.',
  fallbackManual:'The image has been saved. Copy the share text below and add it in your chosen app.',
  failed:'Could not prepare the image. Copying the share text is still available.',
  clipboardDone:'Image copied. Paste it into an app that supports image pasting.',
  clipboardNo:'Image copying is unavailable here. Use Save image instead.',
  copyImage:'Copy image',downloaded:'Share image saved.',
  linkNote:'Share text copied. Paste it into the LinkedIn or Facebook composer and review the final post.',
  xNote:'Check the length in the X composer. Your text has not been shortened automatically.',
  previewNote:'This previews the content you share. Each social app may display it differently.',
  publication:'Connect a published site',rootURL:'HTTPS address of your deployed journal',
  credit:'Ahyoung Park · Eunji Kang',selected:'A passage from the essay',excerpt:'Essay introduction',withLink:'Article link',noLink:'Public URL not yet connected',
  fullQuote:'Long passages are shortened only in the image; the complete selection remains in the share text.'
 };
 function isLocal(host){
  return !host||host==='localhost'||host==='::1'||host==='[::1]'||host==='example.com'||host==='example.org'||host==='example.net'||/\.(localhost|local|test|example|invalid)$/.test(host)||/^127\.|^0\.|^10\.|^192\.168\.|^169\.254\.|^172\.(1[6-9]|2\d|3[01])\./.test(host)||/^\[(fc|fd|fe80)/i.test(host);
 }
 function baseURL(raw){
  try{const u=new URL(raw);if(u.protocol!=='https:'||isLocal(u.hostname)||u.username||u.password)return null;u.hash='';u.search='';if(/\.[a-z0-9]+$/i.test(u.pathname))u.pathname=u.pathname.slice(0,u.pathname.lastIndexOf('/')+1);else if(!u.pathname.endsWith('/'))u.pathname+='/';return u;}catch(_){return null;}
 }
 function publicURL(){
  const base=baseURL(db.publicBaseUrl||config.publicBaseUrl||location.href);if(!base||!current)return null;
  const mapped=config.publicArticleUrls?.[articleKey()];let u;
  try{u=mapped?new URL(mapped):new URL(`article-${current.id}-${current.lang}.html`,base);if(u.protocol!=='https:'||isLocal(u.hostname)||u.username||u.password)return null;}catch(_){return null;}
  if(shareAnchor){const p=new URLSearchParams({lang:current.lang,p:shareAnchor.block,quote:shareAnchor.text.slice(0,150)});u.hash='article/'+current.id+'?'+p;}
  return u.href;
 }
 const shareIntro=()=>window.CivicJournal.summaries[current?.id]||'';
 function shareText(withURL=true){
  const thought=shareMode==='thought'?shareThought.trim():'';
  return [thought,shareQuote?'“'+shareQuote+'”':'',current.title,!shareQuote?shareIntro():'',SW().credit+' · Civic Ledger',withURL?publicURL():''].filter(Boolean).join('\n\n');
 }
 function shareDialog(quote='',anchor=null){
  if(!current)return;shareQuote=quote;shareAnchor=anchor;shareMode='plain';shareThought='';shareFocus=document.activeElement;hideSelection();window.getSelection()?.removeAllRanges();renderShare();$('#cl-share').showModal();$('#cl-share').scrollTop=0;updateDock();
 }

 function shareTargetMarkup(){
  const choices=ko()?['linkedin','naver','facebook','email','copy']:['linkedin','x','email','copy','facebook'];
  const labels={linkedin:'LinkedIn',x:'X',facebook:'Facebook',naver:ko()?'네이버':'Naver',email:ko()?'이메일':'Email',copy:ko()?'복사':'Copy'};
  const symbols={linkedin:'<span class="cl-share-letter" aria-hidden="true">in</span>',x:'<span class="cl-share-letter cl-x-letter" aria-hidden="true">𝕏</span>',facebook:'<span class="cl-share-letter cl-facebook-letter" aria-hidden="true">f</span>',naver:'<span class="cl-share-letter" aria-hidden="true">N</span>',email:icon('mail'),copy:icon('copy')};
  return choices.map(key=>{
   const label=labels[key],inner=`<span class="cl-share-symbol" aria-hidden="true">${symbols[key]}</span><span class="cl-share-label">${esc(label)}</span>`;
   if(key==='copy')return `<button type="button" class="cl-share-target" data-share-copy-all aria-label="${ko()?'공유 문구와 링크 복사':'Copy share text and link'}">${inner}</button>`;
   return `<a class="cl-share-target" data-share-platform="${key}"${key==='email'?'':' target="_blank" rel="noopener noreferrer"'} aria-label="${esc(ko()?label+'로 공유':'Share via '+label)}">${inner}</a>`;
  }).join('');
 }
 function renderShare(){
  const d=$('#cl-share'),w=SW(),url=publicURL();
  d.lang=current.lang;
  d.innerHTML=`<div class="cl-dialog-heading"><h2 id="cl-share-heading">${esc(T().shareHeading)}</h2><button class="cl-dialog-close" type="button" data-cl-action="close-share" aria-label="${esc(T().cancel)}">${icon('close')}</button></div>
   <div class="cl-share-layout"><div class="cl-share-preview-col"><p class="cl-share-eyebrow">${esc(w.preview)}</p><div class="cl-post-preview"><p id="cl-post-thought" class="cl-post-thought" hidden></p><div id="cl-card-loading" class="cl-card-loading">${esc(w.loading)}</div><img id="cl-card-preview" class="cl-card-preview" alt="${esc(current.title)}" hidden></div><p class="cl-platform-help">${esc(w.previewNote)}</p><details class="cl-share-caption"><summary>${esc(w.caption)}</summary><textarea id="cl-caption-text" readonly aria-label="${esc(w.caption)}"></textarea></details></div>
   <div class="cl-share-settings"><div class="cl-share-mode" role="group" aria-label="${esc(T().share)}"><button type="button" data-share-mode="plain" aria-pressed="${shareMode==='plain'}">${esc(w.plain)}</button><button type="button" data-share-mode="thought" aria-pressed="${shareMode==='thought'}">${esc(w.thought)}</button></div>
   <p class="cl-share-autofill">${esc(shareQuote?w.quoted:w.auto)}</p>
   <div class="cl-thought-editor" id="cl-thought-editor" ${shareMode==='plain'?'hidden':''}><label for="cl-share-thought">${esc(w.yourThought)}<span id="cl-thought-count" class="cl-charcount">0 / 500</span></label><textarea id="cl-share-thought" maxlength="500" rows="4" placeholder="${esc(w.placeholder)}">${esc(shareThought)}</textarea><p class="cl-platform-help">${esc(w.privacy)}</p></div>
   <div class="cl-share-targets" role="group" aria-label="${ko()?'공유 방법':'Sharing options'}">${shareTargetMarkup()}</div>
   <button type="button" class="cl-share-primary" data-cl-action="native-share" id="cl-share-send" disabled>${icon('share')} ${esc(w.send)}</button>
   <div class="cl-share-secondary"><button type="button" data-share-download>${esc(w.save)} ↓</button><button type="button" data-share-copy-image>${esc(w.copyImage)}</button>${url?`<button type="button" data-cl-action="copy-link">${esc(T().copyLink)}</button>`:''}</div>
   <p id="cl-share-feedback" class="cl-share-feedback" role="status"></p>
   <p class="cl-share-note">${esc(url?w.platform:w.local)}</p>${shareQuote.length>350?`<p class="cl-platform-help">${esc(w.fullQuote)}</p>`:''}
   <div id="cl-copy-manual" class="cl-copy-manual" hidden><label>${esc(T().manualCopy)}<textarea readonly rows="5"></textarea></label></div>
   <details class="cl-share-config"><summary>${esc(w.publication)}</summary><form id="cl-url-form"><label for="cl-public-url">${esc(w.rootURL)}</label><input type="url" id="cl-public-url" placeholder="https://your-site.example/journal/" value="${esc(db.publicBaseUrl||config.publicBaseUrl||'')}"><button class="cl-text-btn" type="submit">${esc(T().publicSave)}</button><button class="cl-text-btn" type="button" data-cl-action="clear-url">${esc(T().clearUrl)}</button><p>${esc(T().publicHint)}</p></form></details>
   </div></div>`;
  $('#cl-share-thought').addEventListener('input',e=>{shareThought=e.target.value.slice(0,500);updateShareState();});
  $('#cl-url-form').addEventListener('submit',e=>{e.preventDefault();const u=baseURL($('#cl-public-url').value.trim());if(!u){toast(T().invalidUrl);return;}db.publicBaseUrl=u.href;save();renderShare();toast(T().linked);});
  updateShareState();prepareShareCard();
 }
 function shareFeedback(text){const e=$('#cl-share-feedback');if(e)e.textContent=text;}
 function updateShareState(){
  if(!current||!$('#cl-caption-text'))return;const thought=shareMode==='thought'?shareThought.trim():'';const el=$('#cl-post-thought');el.textContent=thought;el.hidden=!thought;
  $('#cl-caption-text').value=shareText();$('#cl-thought-count').textContent=shareThought.length+' / 500';
  $$('#cl-share [data-share-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.shareMode===shareMode)));$('#cl-thought-editor').hidden=shareMode!=='thought';
  const url=publicURL();const xText=[thought,shareQuote?'“'+shareQuote+'”':current.title,!shareQuote?shareIntro():''].filter(Boolean).join('\n\n');
  const urls={x:'https://twitter.com/intent/tweet?'+new URLSearchParams({text:xText,...(url?{url}: {})}),linkedin:url?'https://www.linkedin.com/sharing/share-offsite/?url='+encodeURIComponent(url):null,facebook:url?'https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(url):null,naver:url?'https://share.naver.com/web/shareView?'+new URLSearchParams({url,title:current.title}):null,email:'mailto:?'+new URLSearchParams({subject:current.title,body:shareText()}).toString().replace(/\+/g,'%20')};
  $$('#cl-share [data-share-platform]').forEach(a=>{const u=urls[a.dataset.sharePlatform];a.href=u||'#';a.dataset.needsUrl=String(!u);a.setAttribute('aria-disabled',String(!u));});
 }
 async function copy(text,quiet=false){
  let ok=false;try{await navigator.clipboard.writeText(text);ok=true;}catch(_){const ta=document.createElement('textarea');ta.value=text;ta.style.cssText='position:fixed;opacity:0;left:0;top:0;width:1px;height:1px';($('#cl-share').open?$('#cl-share'):document.body).append(ta);ta.select();try{ok=document.execCommand('copy');}catch(_){}ta.remove();}
  if(ok){if(!quiet)toast(T().copied);}else{const box=$('#cl-copy-manual');if(box){box.hidden=false;box.querySelector('textarea').value=text;}if(!quiet)toast(T().copyFail);}return ok;
 }
 function downloadCard(){
  if(!shareCardBlob){shareFeedback(SW().loading);return false;}const a=document.createElement('a'),u=URL.createObjectURL(shareCardBlob);a.href=u;a.download=`Civic_Ledger_${current.id}_${current.lang}_${shareQuote?'Quote':'Article'}.png`;a.click();setTimeout(()=>URL.revokeObjectURL(u),10000);shareFeedback(SW().downloaded);return true;
 }
 async function copyCard(){
  if(!shareCardBlob){shareFeedback(SW().loading);return;}
  try{if(!navigator.clipboard?.write||!globalThis.ClipboardItem)throw Error('unsupported');await navigator.clipboard.write([new ClipboardItem({'image/png':shareCardBlob})]);shareFeedback(SW().clipboardDone);}catch(_){shareFeedback(SW().clipboardNo);}
 }
 async function nativeShare(){
  if(!current)return;
  if(!shareCardFile){shareFeedback(SW().loading);return;}
  const data={files:[shareCardFile],title:current.title,text:shareText(false),...(publicURL()?{url:publicURL()}:{})};
  if(navigator.share&&navigator.canShare?.({files:data.files})){
   try{await navigator.share(data);shareFeedback(SW().noteSent);}catch(e){if(e.name!=='AbortError')shareFeedback(ko()?'앱에 전달하지 못했습니다. 이미지 저장과 공유 문구 복사를 이용해 주세요.':'Could not hand the image to the app. Use Save image and Copy share text.');}return;
  }
  downloadCard();const ok=await copy(shareText(),true);shareFeedback(ok?SW().fallback:SW().fallbackManual);
 }
 // A deterministic image compositor: no uploaded font files, no external graphics
 // service, no user text in query strings, and no hidden private annotation data.
 function wrapLines(ctx,text,width){
  const lines=[];for(const paragraph of String(text).split('\n')){let line='';for(const token of (paragraph.match(/\S+\s*|\s+/gu)||[''])){
   if(ctx.measureText(line+token).width<=width){line+=token;continue;}
   if(line.trim()){lines.push(line.trimEnd());line='';}
   if(ctx.measureText(token).width>width){for(const c of Array.from(token)){if(line&&ctx.measureText(line+c).width>width){lines.push(line.trimEnd());line='';}line+=c;}}
   else line=token;
  }lines.push(line.trimEnd());}return lines;
 }
 const shareInk=()=>getComputedStyle(document.documentElement).getPropertyValue('--writing-base').trim()||'#3658a3';
 function drawLines(ctx,text,x,y,width,{size=46,min=34,weight=600,lineHeight=1.38,maxLines=3,maxHeight=Infinity,family='sans-serif',color=shareInk(),ellipsis=true}={}){
  let lines;for(let n=size;n>=min;n--){ctx.font=`${weight} ${n}px ${family}`;lines=wrapLines(ctx,text,width);size=n;if(lines.length<=maxLines&&lines.length*size*lineHeight<=maxHeight)break;}
  maxLines=Math.min(maxLines,Math.max(1,Math.floor(maxHeight/(size*lineHeight))));const overflow=lines.length>maxLines;lines=lines.slice(0,maxLines);
  if(overflow&&ellipsis){let last=lines[lines.length-1]||'';while(last&&ctx.measureText(last+'…').width>width)last=last.slice(0,-1);lines[lines.length-1]=last+'…';}
  ctx.fillStyle=color;ctx.textBaseline='top';lines.forEach((l,i)=>ctx.fillText(l,x,y+i*size*lineHeight));return {bottom:y+lines.length*size*lineHeight,size,overflow};
 }
 async function drawShareCard(id,locale,quote='',wide=false){
  const journal=window.CivicJournal,data=journal.data,a=data.articles[id+'-'+locale];const coverSlot=data.thumbnailSlots?.[id];const imageKey=coverSlot?.src||data.thumbnails[id];const pic=new Image();
  // Standalone previews use data URLs; the public site uses local, same-origin asset URLs.
  const hasImage=!!data.assets[imageKey];if(hasImage)await new Promise((resolve,reject)=>{pic.onload=resolve;pic.onerror=reject;pic.src=data.assets[imageKey];});
  await Promise.race([document.fonts?.ready||Promise.resolve(),new Promise(r=>setTimeout(r,1200))]);
  const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=wide?630:1200;const c=canvas.getContext('2d');if(!c)throw Error('Canvas unavailable');
  const family=locale==='ko'?'"Pretendard Variable", "Noto Sans CJK KR", "Apple SD Gothic Neo", sans-serif':'"Bricolage Grotesque", Arial, sans-serif';
  c.fillStyle='#faf8f1';c.fillRect(0,0,canvas.width,canvas.height);
  const intro=a.description||'';const issue=a.collection==='technical'?'TECHNICAL PAPER ARTICLE 2':String(id).padStart(2,'0');
  function fitImage(x,y,w,h){
   if(!hasImage)return;
   if(coverSlot?.fit==='cover'){
    const scale=Math.max(w/pic.naturalWidth,h/pic.naturalHeight);
    const sw=w/scale,sh=h/scale;
    const sx=(pic.naturalWidth-sw)*(coverSlot.focalX??.5),sy=(pic.naturalHeight-sh)*(coverSlot.focalY??.5);
    c.drawImage(pic,sx,sy,sw,sh,x,y,w,h);
   }else{
    const scale=Math.min(w/pic.naturalWidth,h/pic.naturalHeight);
    const iw=pic.naturalWidth*scale,ih=pic.naturalHeight*scale;
    c.drawImage(pic,x+(w-iw)/2,y+(h-ih)/2,iw,ih);
   }
   if(coverSlot?.credit){
    c.save();const size=Math.min(17,Math.max(10,w/40));
    c.font=`400 ${size}px ${family}`;c.textBaseline='alphabetic';
    const credit=coverSlot.credit,pad=8,tw=c.measureText(credit).width;
    c.fillStyle='rgba(15,25,30,.72)';c.fillRect(x+w-tw-2*pad-8,y+h-size-2*pad-6,tw+2*pad,size+2*pad);
    c.fillStyle='#fff';c.fillText(credit,x+w-tw-pad-8,y+h-pad-7);c.restore();
   }
  }const by=locale==='ko'?'박아영 · 강은지':'Ahyoung Park · Eunji Kang';
  if(wide){
   c.fillStyle=shareInk();c.fillRect(0,0,10,630);drawLines(c,'CIVIC LEDGER  /  '+issue,48,40,1080,{size:20,min:20,weight:600,maxLines:1,family});
   fitImage(620,138,535,400);
   const title=drawLines(c,a.title,48,144,hasImage?520:1060,{size:hasImage?42:56,min:30,maxLines:hasImage?5:3,family,lineHeight:1.36});
   drawLines(c,intro,48,title.bottom+26,hasImage?520:1000,{size:hasImage?22:28,min:20,maxLines:3,weight:400,color:'#62695e',family,lineHeight:1.5});
   drawLines(c,by,48,574,1050,{size:18,min:18,weight:400,maxLines:1,family,color:'#687465'});
  }else if(quote){
   drawLines(c,'CIVIC LEDGER  /  '+issue,64,60,1050,{size:26,min:26,maxLines:1,family});
   c.fillStyle=shareInk();c.fillRect(64,154,96,6);
   drawLines(c,'“'+quote+'”',64,206,1072,{size:54,min:34,maxLines:11,maxHeight:700,family,weight:500,lineHeight:1.5});
   c.strokeStyle='#ccd4de';c.beginPath();c.moveTo(64,960);c.lineTo(1136,960);c.stroke();
   fitImage(930,996,206,170);
   drawLines(c,a.title,64,998,818,{size:30,min:23,maxLines:3,family,lineHeight:1.42});
   drawLines(c,by,64,1138,818,{size:22,min:22,maxLines:1,family,weight:400,color:'#65705e'});
  }else{
   const h=hasImage?Math.min(600,1200*pic.naturalHeight/pic.naturalWidth):220;fitImage(0,0,1200,h);if(!hasImage){drawLines(c,a.topic||'AI',56,70,1088,{size:54,min:38,maxLines:2,family});}
   const top=h+32;drawLines(c,'CIVIC LEDGER  /  '+issue,56,top,1088,{size:23,min:23,maxLines:1,family});
   const title=drawLines(c,a.title,56,top+50,1088,{size:51,min:38,maxLines:3,family,lineHeight:1.3});
   drawLines(c,intro,56,title.bottom+22,1088,{size:28,min:23,weight:400,maxLines:2,family,color:'#60685d',lineHeight:1.45});
   drawLines(c,by,56,1143,1088,{size:22,min:22,weight:400,maxLines:1,family,color:'#69715f'});
  }
  return canvas;
 }
 async function prepareShareCard(){
  const seq=++shareRenderSeq,ctx={...current},q=shareQuote;shareCardBlob=null;shareCardFile=null;
  try{
   const canvas=await drawShareCard(ctx.id,ctx.lang,q);const blob=await new Promise((res,rej)=>canvas.toBlob(b=>b?res(b):rej(Error('PNG export failed')),'image/png'));
   if(seq!==shareRenderSeq||!current||current.id!==ctx.id||current.lang!==ctx.lang)return;
   if(shareCardURL)URL.revokeObjectURL(shareCardURL);shareCardBlob=blob;shareCardFile=new File([blob],`Civic_Ledger_${ctx.id}_${ctx.lang}.png`,{type:'image/png'});shareCardURL=URL.createObjectURL(blob);
   $('#cl-card-preview').src=shareCardURL;$('#cl-card-preview').hidden=false;$('#cl-card-loading').hidden=true;$('#cl-share-send').disabled=false;
  }catch(_){if(seq===shareRenderSeq){$('#cl-card-loading').textContent=SW().failed;shareFeedback(SW().failed);}}
 }
 // Export-only hook also used to create crawler-visible static preview images.
 window.CivicShareAssets={draw:drawShareCard};
 document.addEventListener('click',e=>{
  const target=e.target.closest('#cl-share button,#cl-share a');if(!target)return;
  if(target.dataset.shareMode){shareMode=target.dataset.shareMode;updateShareState();if(shareMode==='thought')$('#cl-share-thought').focus({preventScroll:true});return;}
  if(target.hasAttribute('data-share-copy-all')){
   copy(shareText(),true).then(ok=>{
    if(!ok){shareFeedback(T().copyFail);return;}
    shareFeedback(ko()?'공유 문구를 복사했습니다. 공개 링크가 연결된 경우 함께 복사됩니다.':'Share text copied, including the article link when configured.');
    const label=target.querySelector('.cl-share-label');label.textContent=ko()?'복사됨':'Copied';target.classList.add('is-copied');
    setTimeout(()=>{if(target.isConnected){label.textContent=ko()?'복사':'Copy';target.classList.remove('is-copied');}},2200);
   });return;
  }
  if(target.hasAttribute('data-share-download'))return downloadCard();
  if(target.hasAttribute('data-share-copy-image'))return copyCard();
  if(target.dataset.sharePlatform){
   if(target.dataset.needsUrl==='true'){e.preventDefault();const det=$('#cl-share .cl-share-config');det.open=true;shareFeedback(T().urlMissing);return;}
   if(['linkedin','naver','facebook'].includes(target.dataset.sharePlatform)){copy(shareText(),true).then(ok=>shareFeedback(ok?SW().linkNote:T().copyFail));}
   if(target.dataset.sharePlatform==='x')shareFeedback(SW().xNote);
  }
 });

 async function api(path,method='GET',body){const res=await fetch(String(config.apiBase).replace(/\/$/,'')+path,{method,credentials:'same-origin',headers:{...(body?{'Content-Type':'application/json'}:{}),...(method!=='GET'&&session?{'X-CSRF-Token':session.csrf}: {})},...(body?{body:JSON.stringify(body)}:{})});if(!res.ok)throw new Error('Discussion API '+res.status);return res.json();}
 async function getShared(serial){try{if(!session)session=await api('/session');if(!current||serial!==mountSerial)return;const state=await api(`/articles/${current.id}`);if(serial!==mountSerial)return;liveState=state;$('#cl-post').disabled=false;renderComments();}catch(_){if(serial===mountSerial){$('#cl-post').disabled=true;$('#cl-storage-note').textContent=T().serverUnavailable;}}}
 // Bind once; article views may be remounted or language-switched many times.
 document.body.insertAdjacentHTML('beforeend',`<div id="cl-selection" class="cl-selection" role="toolbar" hidden></div><dialog id="cl-share" class="cl-reader cl-share-dialog" aria-labelledby="cl-share-heading"></dialog>`);
 $('#cl-selection').addEventListener('pointerdown',e=>{if(e.target.closest('button'))e.preventDefault();});
 $('#cl-share').addEventListener('close',()=>{shareFocus?.focus?.({preventScroll:true});updateDock();});
 $('#cl-share').addEventListener('click',e=>{if(e.target===e.currentTarget){const r=e.currentTarget.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.currentTarget.close();}});
 document.addEventListener('pointerup',e=>{if(e.target.closest('.cl-reader,.cl-selection'))return;setTimeout(captureSelection,25);});
 let selTimer;
 document.addEventListener('selectionchange',()=>{clearTimeout(selTimer);selTimer=setTimeout(captureSelection,220);});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){hideSelection();selection=null;}if(e.key==='ArrowLeft'||e.key==='ArrowRight'){const b=e.target.closest('[data-cl-tab]');if(b){e.preventDefault();const next=b.dataset.clTab==='comments'?'highlights':'comments';setTab(next,false);$(`[data-cl-tab="${next}"]`).focus();}}});
 document.addEventListener('input',e=>{if(e.target.dataset.clMemo){const h=highs().find(h=>h.id===e.target.dataset.clMemo);if(h){h.memo=e.target.value.slice(0,1500);save();}}});
 document.addEventListener('click',e=>{
  const b=e.target.closest('button,a,mark.cl-highlight');if(!b||!current)return;
  const a=b.dataset.clAction;
  if(a==='like')return toggleLike();
  if(a==='refresh-comments')return getShared(mountSerial);
  if(a==='comments')return setTab('comments');
  if(a==='highlights')return setTab('highlights');
  if(a==='share')return shareDialog();
  if(a==='cancel-compose')return cancelCompose();
  if(a==='remove-quote'){quoted=null;return composeContext();}
  if(a==='export')return exportNotes();
  if(a==='close-share')return $('#cl-share').close();
  if(a==='copy-link')return copy(publicURL()||shareText());
  if(a==='copy-share')return copy(shareText());
  if(a==='native-share')return nativeShare();
  if(a==='missing-url'){const d=$('.cl-share-config');d.open=true;toast(T().urlMissing);return;}
  if(a==='clear-url'){db.publicBaseUrl='';save();return renderShare();}
  if(b.dataset.clTab)return setTab(b.dataset.clTab,false);
  if(b.dataset.clSelection){const action=b.dataset.clSelection,sel=selection;if(action==='close'){hideSelection();window.getSelection()?.removeAllRanges();return;}if(!sel)return;if(action==='highlight')return saveHighlight(sel);if(action==='comment')return quoteInComment(sel);if(action==='share')return shareDialog(sel.text,sel.segments[0]);}
  if(b.dataset.clReply){editing=null;replyTo=b.dataset.clReply;quoted=null;setTab('comments');composeContext();$('#cl-comment-body').focus({preventScroll:true});return;}
  if(b.dataset.clEdit){const c=comments().find(c=>c.id===b.dataset.clEdit);if(!c)return;editing=c.id;replyTo=c.parent;quoted=c.quote?{text:c.quote,lang:c.quoteLang}:null;$('#cl-name').value=c.name;$('#cl-comment-body').value=c.body;setTab('comments');composeContext();updateCharCount();$('#cl-comment-body').focus({preventScroll:true});return;}
  if(b.dataset.clDelete)return deleteComment(b.dataset.clDelete);
  if(b.dataset.clJump)return jumpHighlight(b.dataset.clJump);
  if(b.dataset.clColour){const h=highs().find(x=>x.id===b.dataset.clColour);if(h){h.colour=b.dataset.colour;save();applyHighlights();renderHighlights();}return;}
  if(b.dataset.clHlDelete){const id=b.dataset.clHlDelete;db.highlights[articleKey()]=highs().filter(h=>h.id!==id);save();applyHighlights();renderHighlights();return;}
  if(b.dataset.clHlComment){const h=highs().find(h=>h.id===b.dataset.clHlComment);if(h)quoteInComment(h);return;}
  if(b.dataset.clHlShare){const h=highs().find(h=>h.id===b.dataset.clHlShare);if(h)shareDialog(h.text,h.segments[0]);return;}
  if(b.dataset.clHighlight&&window.getSelection()?.isCollapsed){setTab('highlights');const el=$(`[data-highlight-entry="${b.dataset.clHighlight}"]`);el?.scrollIntoView({block:'center',behavior:reduced()?'instant':'smooth'});return;}
 });
 window.addEventListener('storage',e=>{if(e.key!==STORE||!e.newValue)return;try{db=JSON.parse(e.newValue);if(current){applyHighlights();renderComments();if(tab==='highlights')renderHighlights();refreshCounts();}}catch(_){} });
 window.addEventListener('focus',()=>{if(current&&live)getShared(mountSerial);});
 document.addEventListener('civic:route',mount);
 mount();
})();

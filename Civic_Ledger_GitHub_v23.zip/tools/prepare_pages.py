"""Prepare the already-built public site for GitHub Pages. Python standard library only.
Copies only public HTML and assets. Never deploys editorial sources or local test servers.
"""
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit, urljoin
import argparse, html, json, re, shutil

ROOT=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser()
parser.add_argument('--base-url',required=True,help='Public HTTPS URL reported by actions/configure-pages.')
parser.add_argument('--output',default='_site')
args=parser.parse_args()
u=urlsplit(args.base_url)
if u.scheme!='https' or not u.hostname or u.username or u.password or u.query or u.fragment:
 parser.error('--base-url must be a public HTTPS directory URL without credentials, query or fragment.')
base=urlunsplit((u.scheme,u.netloc,u.path.rstrip('/')+'/','',''))
out=(ROOT/args.output).resolve()
if out==ROOT or ROOT not in out.parents:
 parser.error('--output must be a subdirectory of this repository.')
out.mkdir(parents=True,exist_ok=True)
shutil.copytree(ROOT/'assets',out/'assets',dirs_exist_ok=True)
config=json.loads((ROOT/'site.config.json').read_text(encoding='utf-8'))
config['publicBaseUrl']=base
jsconfig='window.CIVIC_READER_CONFIG=Object.assign('+json.dumps(config,ensure_ascii=False).replace('</','<\\/')+',window.CIVIC_READER_CONFIG||{});'
htmls=[ROOT/n for n in ['index.html','ko.html','events.html','catalogue.html']]+sorted(ROOT.glob('article-*.html'))
for p in htmls:
 s=p.read_text(encoding='utf-8')
 if p.name.startswith('article-'):
  # Crawlers read the real title/description and absolute image URL before the reading redirect.
  s=re.sub(r'<meta\s+name="robots"\s+content="noindex"\s*/?>','',s,flags=re.I)
  s=re.sub(r'<meta\s+(?:property="og:(?:url|image)"|name="twitter:image")\s+content="[^"]*"\s*/?>','',s,flags=re.I)
  s=re.sub(r'<link\s+rel="canonical"\s+href="[^"]*"\s*/?>','',s,flags=re.I)
  canonical=html.escape(urljoin(base,p.name),quote=True)
  picture=html.escape(urljoin(base,'assets/share/'+p.stem+'.jpg'),quote=True)
  s=s.replace('</head>',f'<meta property="og:url" content="{canonical}"><link rel="canonical" href="{canonical}"><meta property="og:image" content="{picture}"><meta name="twitter:image" content="{picture}"></head>')
 else:
  s,n=re.subn(r'window\.CIVIC_READER_CONFIG=Object\.assign\([\s\S]*?,window\.CIVIC_READER_CONFIG\|\|\{\}\);',lambda _:jsconfig,s,count=1)
  if n!=1:raise RuntimeError('Missing public runtime config in '+p.name)
  title=re.search(r'<title>(.*?)</title>',s,re.S).group(1)
  description=re.search(r'<meta name="description" content="([^"]*)"',s).group(1)
  canonical=html.escape(urljoin(base,'' if p.name=='index.html' else p.name),quote=True)
  picture=html.escape(urljoin(base,'assets/share/archive-default.png'),quote=True)
  sharing=f'<link rel="canonical" href="{canonical}"><meta property="og:type" content="website"><meta property="og:site_name" content="Civic Ledger"><meta property="og:title" content="{title}"><meta property="og:description" content="{description}"><meta property="og:url" content="{canonical}"><meta property="og:image" content="{picture}"><meta property="og:image:alt" content="Civic Ledger — points, rewards and collective life"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{title}"><meta name="twitter:description" content="{description}"><meta name="twitter:image" content="{picture}">'
  s=s.replace('</head>',sharing+'</head>')

 (out/p.name).write_text(s,encoding='utf-8')
(out/'.nojekyll').write_text('',encoding='utf-8')
# Guard against accidentally publishing local development or editorial material.
for p in out.rglob('*'):
 if p.is_file() and (p.suffix.lower() in {'.docx','.py','.zip','.woff','.woff2','.ttf','.otf'} or 'NOT_FOR_PUBLICATION' in p.name):
  raise RuntimeError('Unexpected non-public file: '+str(p.relative_to(out)))
print(f'Ready: {len(htmls)} entry pages at {base} -> {out}')

(() => {
  const production = ['civicledger.city', 'www.civicledger.city', 'archive.civicledger.city'];
  if (production.includes(location.hostname)) return;
  const root = new URL('../', document.currentScript.src);
  function localise() {
    document.querySelectorAll('a[href]').forEach(a => {
      let u; try { u = new URL(a.getAttribute('href'), location.href); } catch { return; }
      let folder;
      if (u.hostname === 'archive.civicledger.city') folder = 'archive/';
      else if (['civicledger.city', 'www.civicledger.city'].includes(u.hostname)) folder = 'homepage/';
      else return;
      if (folder === 'homepage/' && !u.searchParams.has('lang')) u.searchParams.set('lang', document.documentElement.lang.startsWith('ko') ? 'ko' : 'en');
      const path = u.pathname === '/' ? 'index.html' : u.pathname.replace(/^\//, '');
      a.href = new URL(folder + path + u.search + u.hash, root).href;
      a.removeAttribute('target');
    });
  }
  localise();
  new MutationObserver(localise).observe(document.body, {subtree:true,childList:true,attributes:true,attributeFilter:['href']});
})();
Civic Ledger v27.2 | Single underline + strategic advisor

This is an update to the supplied v27.1 website package, not a live deployment.

Changes
- Project team / 프로젝트팀: one thin underline in normal, hover and keyboard-focus states.
- Existing arrow and subtle hover movement remain.
- Strategic advisors / 전략 자문: added Jungeun Kim with affiliation Inha University.
- The supplied English spelling is used in both languages. No biography or profile URL was invented.
- All eight team profiles, portraits, existing links, page layout and unrelated content remain unchanged.

Full package
The website/ directory contains the updated site files. index.html is its entry point.
Only two assets and four cache-busting HTML references differ from v27.1.

Patch package
Apply only to the matching v27.1 website folder. It contains the changed assets and the four entry-point HTML files.
Do not apply these HTML/data files over a different newer site version without merging changes first.

Verification
Desktop and mobile, English and Korean; team popup opens and closes; all 8 portraits load;
6 strategic advisors shown; single 1px solid underline after keyboard opening and closing;
no horizontal overflow in the tested mobile layout. Tested in an in-memory Chromium preview.
No external font downloads were required for these checks.

Nothing has been pushed to GitHub or published to archive.civicledger.city.

Civic Ledger archive — navigation update — 2026-11-03

Includes all published v27.2 files plus the fourth Use cases tab, bilingual Coming soon section and homepage logo link. Publish the contents of website/. The package retains its existing name and folder layout for the GitHub Pages workflow.

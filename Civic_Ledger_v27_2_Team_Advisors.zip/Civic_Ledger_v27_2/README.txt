Civic Ledger archive — event and navigation update — 2026-11-03

Includes all published v27.2 files plus the fourth Use cases tab, inline bilingual Coming soon status, homepage logo link, upcoming Seoul conversations for November–December and a short generic October Berlin learning record. The August entry remains unchanged. Publish the contents of website/. The package retains its existing name and folder layout for the GitHub Pages workflow.

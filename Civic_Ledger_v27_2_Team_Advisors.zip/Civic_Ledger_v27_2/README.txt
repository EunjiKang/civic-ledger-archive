Civic Ledger archive — animated PoC previews — 2026-11-03

The complete output ZIP includes the original poc1.gif and poc2.gif supplied by Eunji Kang, with static pause frames, playback controls and reduced-motion support. PoC 1 previews a forthcoming agreement game. PoC 2 previews a service module using synthetic data. Both use the bilingual pitch-deck titles.

All four archive page introductions share their typography, spacing and layout. Project team accents follow the active section. Existing event records and other archive content are retained.

Publish the contents of website/. For GitHub browser uploads, use the separate core and simulation-media archives with the updated Pages workflow.

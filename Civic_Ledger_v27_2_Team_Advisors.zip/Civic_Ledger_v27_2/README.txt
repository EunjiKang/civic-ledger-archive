Civic Ledger archive — events and use-case previews — 2026-11-03

Includes all published v27.2 files plus the fourth Use cases tab, inline bilingual Coming soon status, homepage logo link, upcoming Seoul conversations for November–December and a short generic October Berlin learning record. The August entry remains unchanged.

Use cases includes two illustrative stills extracted from Civic_Ledger_pitch_deck_EN-KO_v2.pdf supplied by Eunji Kang (pages 7 and 12). Counts and approvals are simulated. Animation files referenced by the separately supplied index.html were not included, so the previews use still images. The Use cases footer is black with light text.

Publish the contents of website/. The package retains its existing name and folder layout for the GitHub Pages workflow.
